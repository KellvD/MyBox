//
//  CDMediaPicker.h
//  CDMediaPicker
//
//  Created by changdong on 2021/2/28.
//  Copyright © 2021 (c) Huawei Technologies Co., Ltd. 2012-2019. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for CDMediaPicker.
FOUNDATION_EXPORT double CDMediaPickerVersionNumber;

//! Project version string for CDMediaPicker.
FOUNDATION_EXPORT const unsigned char CDMediaPickerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CDMediaPicker/PublicHeader.h>


