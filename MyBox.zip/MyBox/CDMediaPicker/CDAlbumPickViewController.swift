//
//  CDImagePickViewController.swift
//  MyRule
//
//  Created by changdong on 2018/12/13.
//  Copyright © 2018 changdong. All rights reserved.
//

import UIKit
import Photos


class CDAlbumPickViewController: UITableViewController,PHPhotoLibraryChangeObserver {
    
    
    private var ablumList:[CDAlbum] = []
    private var folderId = Int()
    var isSelectedVideo:Bool!
    weak var assetDelegate:CDAssetSelectedDelagete!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.separatorStyle = .none
        tableView.register(CDAlbumCell.self, forCellReuseIdentifier: "CDAlbumCell")
        self.navigationController!.navigationBar.topItem?.title = ""
        let cancle = UIBarButtonItem(barButtonSystemItem: .cancel, target: assetDelegate, action: #selector(cancleMediaPicker))
        self.navigationItem.rightBarButtonItem = cancle
        
        let status = PHPhotoLibrary.authorizationStatus(for: .readWrite)
        if status == .limited {
            PHPhotoLibrary.shared().register(self)
        }
        self.loadAllAlbum()

    }
    
    func photoLibraryDidChange(_ changeInstance: PHChange) {
        DispatchQueue.main.async {
            self.loadAllAlbum()
        }
        
    }

    @objc func cancleMediaPicker(){}
    
    
    func loadAllAlbum() {
        CDAssetTon.shared.getAllAlbums { (albumArr) in
            self.ablumList.removeAll()
            self.ablumList = albumArr
            //排序降序
            self.ablumList.sort(by: { (photo1, photo2) -> Bool in
                return photo1.fetchResult.count > photo2.fetchResult.count
            })
            self.reloadTableView()
        }
    }
    func reloadTableView() {
        DispatchQueue.main.async {
            self.tableView.reloadData()
            self.navigationItem.title = self.isSelectedVideo ? "视频" : "图片"
        }
    }


    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.ablumList.count
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 85
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentify = "CDAlbumCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentify) as! CDAlbumCell
        let alum:CDAlbum = ablumList[indexPath.row]
        cell.titleLabel.text = alum.title;
        cell.countlabel.text = "\(alum.fetchResult.count) 张"
        cell.headImage.image = alum.coverImage
        cell.separatorLine.isHidden = indexPath.row == ablumList.count - 1
        return cell


    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let alum:CDAlbum = ablumList[indexPath.row]
        let imageItemVC = CDAssetPickViewController()
        imageItemVC.albumItem = alum
        imageItemVC.isVideo = isSelectedVideo
        imageItemVC.assetDelegate = assetDelegate
        self.navigationController?.pushViewController(imageItemVC, animated: true)

    }

   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

class CDAlbumCell: UITableViewCell {
    var headImage: UIImageView!
    var countlabel: UILabel!
    var titleLabel: UILabel!
    var separatorLine: UILabel!
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.backgroundColor = UIColor(red: 240/255.0, green: 240/255.0, blue: 240/255.0, alpha: 1.0)
        let view = UIView()
        self.selectedBackgroundView = view
        self.selectedBackgroundView?.backgroundColor = UIColor(red: 213.0/255.0, green: 230.0/255.0, blue: 244.0/255.0, alpha: 1.0)

        headImage = UIImageView(frame: CGRect(x: 15, y: 15, width: 55, height: 55))
        headImage.tag = 101
        self.contentView.addSubview(headImage)

        titleLabel = UILabel(frame: CGRect(x: headImage.frame.maxX+15, y: headImage.frame.minY+5, width: 100, height: 30))
        titleLabel.tag = 102
        titleLabel.font = UIFont.systemFont(ofSize: 17)
        titleLabel.textColor = UIColor(red:61/255.0, green:81/255.0,blue:97/255.0,alpha:1.0)
        self.contentView.addSubview(titleLabel)

        
        countlabel = UILabel(frame: CGRect(x: headImage.frame.maxX+15, y: titleLabel.frame.maxY, width: 100, height: 15))
        countlabel.tag = 103
        countlabel.font = UIFont.systemFont(ofSize: 12)
        countlabel.textColor = UIColor(red:154/255.0, green:154/255.0,blue:154/255.0,alpha:1.0)
        self.contentView.addSubview(countlabel)

        separatorLine = UILabel(frame: CGRect(x: 15, y: 84, width: CDSCREEN_WIDTH-15, height: 1))
        separatorLine.tag = 104
        separatorLine.backgroundColor = .white
        self.contentView.addSubview(separatorLine)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
