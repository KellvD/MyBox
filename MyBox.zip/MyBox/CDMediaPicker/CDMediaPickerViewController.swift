//
//  CDMediaPickerViewController.swift
//  MyRule
//
//  Created by changdong on 2019/5/6.
//  Copyright © 2019 changdong. All rights reserved.
//

import UIKit
import CoreLocation

struct JYMediaMode {
    var fileName: String?
    var image: UIImage?
    var data: Data?
    var filePath:String?
    var imageType: PhotoFormat?
    var createTime:Int?
    var location: CLLocation?
}
public protocol CDMediaPickerViewControllerDelegate{
    func onMediaPickerDidFinished(picker:CDMediaPickerViewController,data:[String:Any?],index:Int,totalCount:Int)
    func onMediaPickerDidCancle(picker:CDMediaPickerViewController)
}

public class CDMediaPickerViewController: UINavigationController,CDAssetSelectedDelagete{
    public var pickerDelegate:CDMediaPickerViewControllerDelegate?
    public var isForVideo = false
    var gphAssets:[CDPHAsset] = []
    var totalCount = 0
    
    var onMediaPickerCompletion:(([UIImage])->Void)?
    public init(isVideo:Bool) {
        CDAssetTon.shared.mediaType = isVideo ? .CDMediaVideo : .CDMediaImage
        let albumVC = CDAlbumPickViewController()
        super.init(rootViewController: albumVC)
        self.navigationBar.tintColor = UIColor.black
        self.navigationBar.isTranslucent = false
        albumVC.assetDelegate = self
        albumVC.isSelectedVideo = isVideo
        isForVideo = isVideo
        

    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    @objc public func cancleMediaPicker() {
        if let delegate = self.pickerDelegate {
            delegate.onMediaPickerDidCancle(picker: self)
        }
        if onMediaPickerCompletion != nil {
            self.dismiss(animated: true)
        }
    }

    func selectedAssetsComplete(phAssets: [CDPHAsset]) {
       
        if isForVideo{
            totalCount = phAssets.count
            self.gphAssets = phAssets
            handleVideo()
        }else{
            var images:[UIImage] = []
            for i in 0..<phAssets.count {
                autoreleasepool {
                    let tmpAsset:CDPHAsset = phAssets[i]
                    //Live图片本地暂无法保存
                    let createTime = Int(tmpAsset.asset.creationDate!.timeIntervalSince1970 * 1000)
                    let location = tmpAsset.asset.location
                    if tmpAsset.format == .Live {
//                        CDAssetTon.shared.getLivePhotoFromAsset(asset: tmpAsset.asset, targetSize: CGSize.zero) { (livePhoto, info) in
//                            if livePhoto != nil{
//                                let dic:[String:Any] = ["fileName":tmpAsset.fileName!,"file":livePhoto!,"image":"live"]
//                                self.pickerDelegate.onMediaPickerDidFinished!(picker: self, data: dic, index: i + 1, totalCount: phAssets.count)
//                            }
//                        }
                        CDAssetTon.shared.getOriginalPhotoFromAsset(asset: tmpAsset.asset) { (image) in
                            guard let image = image else {
                                return
                            }
                            let dic:[String:Any?] = ["fileName":tmpAsset.fileName!,
                                                         "file":image,
                                                        "imageType":"normal",
                                                        "createTime":createTime,
                                                        "location":location]
                                self.pickerDelegate?.onMediaPickerDidFinished(picker: self, data: dic, index: i + 1, totalCount: phAssets.count)
                                images.append(image)
                            
                        }
                    }else if tmpAsset.format == .Gif {
                        CDAssetTon.shared.getImageDataFromAsset(asset: tmpAsset.asset) { (data, info) in
                            guard let data = data else {
                                return
                            }
                            let dic:[String:Any?] = ["fileName":tmpAsset.fileName!,
                                                    "file":data,
                                                    "imageType":"gif",
                                                    "createTime":createTime,
                                                    "location":location]
                            self.pickerDelegate?.onMediaPickerDidFinished(picker: self, data: dic, index: i + 1, totalCount: phAssets.count)
                            images.append(UIImage(data: data)!)
                        }

                    }else{
                        CDAssetTon.shared.getOriginalPhotoFromAsset(asset: tmpAsset.asset) { (image) in
                            guard let image = image else {
                                return
                            }
                            let dic:[String:Any?] = ["fileName":tmpAsset.fileName!,
                                                    "file":image,
                                                    "imageType":"normal",
                                                    "createTime":createTime,
                                                    "location":location]
                            self.pickerDelegate?.onMediaPickerDidFinished(picker: self, data: dic, index: i + 1, totalCount: phAssets.count)
                            images.append(image)

                        }
                    }
                    
                    
                }
            }
            if let handler = onMediaPickerCompletion {
                self.dismiss(animated: true)
                handler(images)
            }
        }
    }

//    GCD队列
    private func handleVideo(){
        let sem = DispatchSemaphore(value: 1)
        DispatchQueue(label: "handleVideo",qos: .default).sync {
            for index in 0..<gphAssets.count{
                sem.wait()
                let tmpAsset = self.gphAssets[index]
                CDAssetTon.shared.getVideoFromAsset(withAsset: tmpAsset.asset) { (tmpPath) in
                    if tmpPath != nil {
                        let dic:[String:Any] = ["fileURL":URL(fileURLWithPath: tmpPath!)]
                        self.pickerDelegate?.onMediaPickerDidFinished(picker: self, data: dic, index: index + 1, totalCount: self.totalCount)
                        sem.signal()
                    }
                }
            }
        }
    }
}

