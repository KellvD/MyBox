//
//  File.swift
//  MyBox
//
//  Created by Kellv on 2024/12/9.
//  Copyright © 2024 Kellvv   . All rights reserved.
//

import Foundation
import UIKit

extension CDBaseAllViewController {
    func alert(title: String? = nil,
               message: String? = nil,
               placeholder: String? = nil,
               filedText: String? = nil,
               defaultTitle:String,
               defaultAction: @escaping ((String?)->Void)) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        var tmpTextFiled: UITextField?
        if let placeholder = placeholder {
            alert.addTextField {[weak self] textFiled in
                guard let self = self else {
                    return
                }
                tmpTextFiled = textFiled
                textFiled.text = filedText
                textFiled.attributedPlaceholder = NSAttributedString(string: placeholder, attributes: [.foregroundColor: UIColor(white: 0.5, alpha: 0.5)])
                textFiled.addTarget(self, action: #selector(self.textFiledDidChange(_:)), for: .editingChanged)
            }
        }
        
        let cancel = UIAlertAction(title: "Cancel".localize(), style: .default)
        alert.addAction(cancel)
        let defaultA = UIAlertAction(title: defaultTitle, style: .default, handler: { (_) in
            defaultAction((tmpTextFiled?.text))
        })
        
        if let placeholder = placeholder {
            defaultA.isEnabled = false
            defaultA.setValue(UIColor.gray, forKey: "titleTextColor")
        }
        alert.addAction(defaultA)
        self.present(alert, animated: true, completion: nil)
        self.alert = alert
    }
    
    @objc func textFiledDidChange(_ textFiled: UITextField) {
        guard let text = textFiled.text,
              let alert = self.alert else {
            return
        }
        if text.count > 16 {
            textFiled.text = textFiled.text?.subString(to: 16)
            CDHUDManager.shared.showText("The maximum length of name is 16 characters".localize())
        }
        alert.actions.last?.isEnabled = !text.isEmpty
        if text.isEmpty {
            alert.actions.last?.setValue(UIColor.gray, forKey: "titleTextColor")
        } else {
            alert.actions.last?.setValue(UIColor.systemBlue, forKey: "titleTextColor")
        }
    }
    
    
    // 分享
    func presentShareActivityWith(dataArr: [NSObject], Complete:@escaping(_ error: Error?) -> Void) {

        let activityVC = UIActivityViewController(activityItems: dataArr, applicationActivities: nil)
        activityVC.completionWithItemsHandler = {(_, complete, _, error) -> Void in
            if complete {
                Complete(error)
            }
        }
        self.present(activityVC, animated: true, completion: nil)
    }

    
    
}
