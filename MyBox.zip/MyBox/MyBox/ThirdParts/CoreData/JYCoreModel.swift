//
//  CDSQLModel.swift
//  MyBox
//
//  Created by changdong on 2020/5/1.
//  Copyright © 2019 baize. All rights reserved.
//

import UIKit
import StoreKit

class JYUserInfo: NSObject {

    var userId: Int = 0
    var pwd: String?
    var thumbPath: String?
    var isRoot: Bool = false
    var validityTime: Int = 0
    var name: String?
    var type: JYUserType = .trmporary
}

class JYFolderInfo: NSObject {

    var name: String?  // 文件夹名称
    var folderId: Int = 0       // 文件夹id
    var folderType: NSFolderType! // 文件夹类型
    var isLock = false           // 文件夹是否新建还是默认
    var fakeType = CDFakeType.invisible         // 文件夹访客可见不可见
    var createTime: Int = 0       // 文件夹创建时间
    var modifyTime: Int = 0 // 修改时间
    var userIds: [Int] = []           // 预留，多账户使用
    var superId: Int = 0          // 多层级文件夹时顶级文件夹的ID
    var path: String?    // 文件夹路径
    var isSelected: Bool = false // 不入库，作为判断文件操作时是否选中，出库时设置为false
    var markInfo:String?
}

class JYFileInfo: NSObject {
    var fileId: Int = 0
    var folderId: Int = 0
    var size: Int = 0
    var width: Float = 0.0
    var height: Float = 0.0
    var timeLength: Float = 0.0
    var createTime: Int = 0 // 创建时间 相册，沙盒导入文件的创建时间
    var modifyTime: Int = 0 // 修改时间
    var importTime: Int = 0 // 导入时间
    var fileType: NSFileType!
    var name: String?
    var fileText: String?
    var thumbPath: String?
    var path: String?
    var markInfo: String?
    var location: String?
    var userId: Int = 0
    var isGrade: Bool = false
    var folderType: NSFolderType! // 文件所属大类
    var isSelected: Bool!
}



enum NSFileType: Int {
    case txt = 0
    case audio = 1
    case image = 2
    case video = 3
    case pdf = 4
    case ppt = 5
    case docx = 6
    case excel = 8
    case rtf = 9
    case gif = 10
    case zip = 11
    case live = 12
    case html = 13
    case other = 14
}


enum JYUserType: String {
    case admin     // 管理员
    case regular   //普通账号
    case trmporary //临时账号
}
