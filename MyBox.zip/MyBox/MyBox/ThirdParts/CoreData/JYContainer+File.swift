//
//  JYContainer+File.swift
//  MyBox
//
//  Created by Kellv on 2024/12/7.
//  Copyright © 2024 Kellv. 2012-2019. All rights reserved.
//

import Foundation
import CoreData
extension JYContainer {
    public func insertFile(file: JYFileInfo) -> Int {
        
        let context = container.viewContext
        guard let core = NSEntityDescription.insertNewObject(forEntityName: "CoreFile",
                                                             into: context) as? CoreFile else {
           return -1
        }
        file.importTime = GetTimestamp()
        file.createTime = file.createTime == 0 ? GetTimestamp() : file.createTime
        file.modifyTime = GetTimestamp()
        file.userId = JYCurrentUser().userId
        
        let fileId = queryMaxFileId() + 1
        core.copy(from: file)
        core.fileId = Int16(fileId)
        
        if context.hasChanges {
            do {
                try context.save()
                return fileId
            } catch {
                print("insertFile - error:\(error)")
            }
        }
        return -1
    }
    
    public func queryMaxFileId() -> Int {
        let context = container.viewContext
        do {
            let cores = try context.fetch(fetchFileRequest)
            return cores.count
        } catch {
            print("queryMaxFileId - error:\(error)")
        }
        return 0
    }
    
    public func queryAllFile(folderId: Int? = nil, fileType:NSFileType? = nil)-> [JYFileInfo] {
        var files: [JYFileInfo] = []

        let context = container.viewContext
        if let folderId = folderId {
            fetchFileRequest.predicate = NSPredicate(format: "folderId = %d",folderId)
        }else if let fileType = fileType{
            fetchFileRequest.predicate = NSPredicate(format: "fileType = %d",
                                                     fileType.rawValue)
        }
        do {
            let cores = try context.fetch(fetchFileRequest)
            for core in cores {
                let file = JYFileInfo()
                file.fetch(from: core)
                files.append(file)
            }
            return files.sorted { f1, f2 in f1.createTime > f2.createTime }
        } catch {
            print("queryAllFile - error:\(error)")
        }
        return []
    }
    
    public func queryFile(fileId: Int) -> JYFileInfo? {
        let context = container.viewContext
        fetchFileRequest.predicate = NSPredicate(format: "fileId = %d",fileId)

        do {
            let cores = try context.fetch(fetchFileRequest)
            if let core = cores.first {
                let file = JYFileInfo()
                file.fetch(from: core)
                return file
            }
        } catch {
            print("queryFile - error:\(error)")
        }
        return nil
    }
    
    func queryFileGrade(fileId: Int) -> Bool {
        let context = container.viewContext
        fetchFileRequest.predicate = NSPredicate(format: "fileId = %d",fileId)

        do {
            let cores = try context.fetch(fetchFileRequest)
            if let core = cores.first {
                return core.isGrade
            }
        } catch {
            print("queryFileGrade - error:\(error)")
        }
        return false
    }
   
    func queryFilesSize(fileType:NSFileType? = nil, folderId: Int? = nil) -> Int {
        let context = container.viewContext
        if let folderId = folderId {
            fetchFileRequest.predicate = NSPredicate(format: "folderId = %d",folderId)
        }else if let fileType = fileType{
            fetchFileRequest.predicate = NSPredicate(format: "fileType = %d",
                                                     fileType.rawValue)
        }
        do {
            let cores = try context.fetch(fetchFileRequest)
            let sizes = cores.map({ $0.size }).reduce(0, +)
            return Int(sizes)
        } catch {
            print("queryFileGrade - error:\(error)")
        }
        return 0
    }
    
    func queryFilesCount(fileType: NSFileType? = nil, folderId: Int? = nil) -> Int {
        let context = container.viewContext
        if let folderId = folderId {
            fetchFileRequest.predicate = NSPredicate(format: "folderId = %d",folderId)
        }else if let fileType = fileType{
            fetchFileRequest.predicate = NSPredicate(format: "fileType = %d",
                                                     fileType.rawValue)
        }
        do {
            let cores = try context.fetch(fetchFileRequest)
            return cores.count
        } catch {
            print("queryFileGrade - error:\(error)")
        }
        return 0
    }
    
    func updateFile(name: String? = nil,
                    markInfo: String? = nil,
                    isGrade: Bool? = nil,
                    folderId: Int? = nil,
                    modifyTime: Int = GetTimestamp(),
                    fileId: Int) {
        let context = container.viewContext
        fetchFileRequest.predicate = NSPredicate(format: "fileId = %d",fileId)
        do {
            let cores = try context.fetch(fetchFileRequest)
            if let core = cores.first {
                if let name = name {
                    core.name = name
                }else if let markInfo = markInfo {
                    core.markInfo = markInfo
                }else if let isGrade = isGrade {
                    core.isGrade = isGrade
                }else if let folderId = folderId {
                    core.folderId = Int16(folderId)
                }
                core.modifyTime = Int64(modifyTime)

            }
            if context.hasChanges {
                try context.save()
            }
        } catch {
            print("updateFile - error:\(error)")
        }
    }
    
    func updateFile(file: JYFileInfo) {
        let context = container.viewContext
        fetchFileRequest.predicate = NSPredicate(format: "fileId = %d",file.fileId)
        do {
            let cores = try context.fetch(fetchFileRequest)
            if let core = cores.first {
                core.copy(from: file)
                core.modifyTime = Int64(GetTimestamp())

            }
            if context.hasChanges {
                try context.save()
            }
        } catch {
            print("updateFile - error:\(error)")
        }
    }
    
    func deleteFile(fileId: Int? = nil,
                    folderId: Int? = nil) {
        let context = container.viewContext
        if let folderId = folderId {
            fetchFileRequest.predicate = NSPredicate(format: "folderId = %d",folderId)
        }else if let fileId = fileId{
            fetchFileRequest.predicate = NSPredicate(format: "fileId = %d",
                                                     fileId)
        }
        do {
            let cores = try context.fetch(fetchFileRequest)
            for core in cores {
                context.delete(core)
            }
            if context.hasChanges {
                try context.save()
            }
        } catch {
            print("deleteFile - error:\(error)")
        }
    }
}
