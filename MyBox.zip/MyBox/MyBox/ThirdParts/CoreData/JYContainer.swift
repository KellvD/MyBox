//
//  BZContainer.swift
//  Figma
//
//  Created by Kellv on 2024/11/27.
//

import Foundation
import CoreData
class JYContainer : NSObject {


    let container = NSPersistentContainer(name: "CDBoxCoreData")
    let fetchFileRequest = NSFetchRequest<CoreFile>(entityName: "CoreFile")
    let fetchUserRequest = NSFetchRequest<CoreUser>(entityName: "CoreUser")
    let fetchFolderRequest = NSFetchRequest<CoreFolder>(entityName: "CoreFolder")
    static let shared = JYContainer()
    private override init() {
        super.init()
        createPersistentContainer()
    }
    
    func createPersistentContainer() {
        container.loadPersistentStores { (description, error) in
            if let error = error {
                fatalError("Error: \(error)")
            }
            print("Load stores success")
        }
    }
    
    private func parseEntities(container: NSPersistentContainer) {
        let entities = container.managedObjectModel.entities
        print("Entity count = \(entities.count)\n")
        for entity in entities {
            print("Entity: \(entity.name!)")
            for property in entity.properties {
                print("Property: \(property.name)")
            }
            print("")
        }
    }
    
   
    
}
