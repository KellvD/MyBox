//
//  JYContainer+Folder.swift
//  MyBox
//
//  Created by Kellv on 2024/12/8.
//  Copyright © 2024 Kellv. 2012-2019. All rights reserved.
//

import Foundation
import CoreData

extension JYContainer {
    public func insertFolder(folder: JYFolderInfo) -> Int {
        
        let context = container.viewContext
        guard let core = NSEntityDescription.insertNewObject(forEntityName: "CoreFolder",
                                                              into: context) as? CoreFolder else {
           return -1
        }
        
        if !folder.userIds.contains(where: { $0 == ADMINUSERID }) {
            folder.userIds.append(ADMINUSERID)
        }
        folder.createTime = GetTimestamp()
        folder.modifyTime = GetTimestamp()
        let folderId = queryMaxFolderId() + 1
        core.copy(from: folder)
        
        core.folderId = Int16(folderId)
        if context.hasChanges {
            do {
                try context.save()
                return folderId
            } catch {
                print("insertFolder - error:\(error)")
            }
        }
        return -1
    }
    
    public func queryMaxFolderId() -> Int {
        let context = container.viewContext
        do {
            let cores = try context.fetch(fetchFolderRequest)
            return cores.count
        } catch {
            print("queryMaxFolderId - error:\(error)")
        }
        return 0
    }
    
    public func queryAllFolder(userId: Int? = nil,
                               superId: Int? = nil,
                               folderType: NSFolderType? = nil)-> [[JYFolderInfo]] {
        var unlockArr: [JYFolderInfo] = []
        var lockArr: [JYFolderInfo] = []
        var folders: [[JYFolderInfo]] = []
        let context = container.viewContext
        if let userId = userId {
            fetchFolderRequest.predicate = NSPredicate(format: "userId CONTAINS[d] %d",userId)
        }else if let superId = superId {
            fetchFolderRequest.predicate = NSPredicate(format: "superId = %d",superId)
        }else if let folderType = folderType {
            fetchFolderRequest.predicate = NSPredicate(format: "folderType = %d",folderType.rawValue)
        }
        do {
            let cores = try context.fetch(fetchFolderRequest)
            for core in cores {
                let folder = JYFolderInfo()
                folder.fetch(from: core)
                if folder.isLock {
                    lockArr.append(folder)
                }else {
                    unlockArr.append(folder)
                }
            }
            folders.append(lockArr.sorted { f1, f2 in f1.createTime > f2.createTime })
            folders.append(unlockArr.sorted { f1, f2 in f1.createTime > f2.createTime })
            return folders        } catch {
            print("queryAllFolder - error:\(error)")
        }
        return folders
    }
    
    public func queryAllFolderExceptSelfType(folderId: Int,
                               folderType: NSFolderType)-> [[JYFolderInfo]] {
        var unlockArr: [JYFolderInfo] = []
        var lockArr: [JYFolderInfo] = []
        var folders: [[JYFolderInfo]] = []
        let context = container.viewContext
        fetchFolderRequest.predicate = NSPredicate(format: "folderId = %d and folderType != %d",folderId,folderType.rawValue)

        do {
            let cores = try context.fetch(fetchFolderRequest)
            for core in cores {
                let folder = JYFolderInfo()
                folder.fetch(from: core)
                if folder.isLock {
                    lockArr.append(folder)
                }else {
                    unlockArr.append(folder)
                }
            }
            
            folders.append(lockArr.sorted { f1, f2 in f1.createTime > f2.createTime })
            folders.append(unlockArr.sorted { f1, f2 in f1.createTime > f2.createTime })
            return folders
        } catch {
            print("queryAllFolderExceptSelfType - error:\(error)")
        }
        return folders
    }
    
    public func queryAllFolderId(superId: Int) -> [Int] {
        var folderIds: [Int] = []

        let context = container.viewContext
        fetchFolderRequest.predicate = NSPredicate(format: "superId = %d",superId)

        do {
            let cores = try context.fetch(fetchFolderRequest)
            for core in cores {
                folderIds.append(Int(core.folderId))
            }
            
            return folderIds
        } catch {
            print("queryAllFolderId - error:\(error)")
        }
        return folderIds
    }
    
    public func queryFolder(folderId: Int)-> JYFolderInfo? {
        let context = container.viewContext
        fetchFolderRequest.predicate = NSPredicate(format: "folderId = \(folderId)")

        do {
            let cores = try context.fetch(fetchFolderRequest)
            if let core = cores.first {
                let folder = JYFolderInfo()
                folder.fetch(from: core)
                return folder
            }

        } catch {
            print("queryFolder - error:\(error)")
        }
        return nil
    }
    
    public func queryFoldersCount(superId: Int) -> Int {
        let context = container.viewContext
        fetchFolderRequest.predicate = NSPredicate(format: "superId = \(superId)")
        do {
            let cores = try context.fetch(fetchFolderRequest)
            return cores.count

        } catch {
            print("queryFoldersCount - error:\(error)")
        }
        return 0
    }

    func updateFolder(name: String? = nil,
                    markInfo: String? = nil,
                    modifyTime: Int = GetTimestamp(),
                      userIds:String? = nil,
                    folderId: Int) {
        let context = container.viewContext
        fetchFolderRequest.predicate = NSPredicate(format: "folderId = %d",folderId)
        do {
            let cores = try context.fetch(fetchFolderRequest)
            if let core = cores.first {
                if let name = name {
                    core.name = name
                }else if let markInfo = markInfo {
                    core.markInfo = markInfo
                }else if let userIds = userIds {
                    core.userId = userIds
                }
                core.modifyTime = Int64(modifyTime)

            }
            if context.hasChanges {
                try context.save()
            }
        } catch {
            print("updateFile - error:\(error)")
        }
    }
    
    func deleteFolder(folderId: Int? = nil,
                      superId: Int? = nil) {
        let context = container.viewContext
        if let folderId = folderId {
            fetchFolderRequest.predicate = NSPredicate(format: "folderId = %d",folderId)
        }else if let superId = superId{
            fetchFolderRequest.predicate = NSPredicate(format: "superId = %d",
                                                     superId)
        }
        do {
            let cores = try context.fetch(fetchFolderRequest)
            for core in cores {
                context.delete(core)
            }
            if context.hasChanges {
                try context.save()
            }
        } catch {
            print("deleteFile - error:\(error)")
        }
    }
    
//    public func queryAllContentFromFolder(folderId: Int) -> (foldersArr: [JYFolderInfo], filesArr: [JYFileInfo]) {
//        var subFileArr = queryAllFileFromFolder(folderId: folderId)
//        var subFolderArr = querySubAllFolder(folderId: folderId)
//        subFileArr.sort { (obj1, obj2) -> Bool in
//            return obj1.createTime > obj2.createTime
//        }
//
//        subFolderArr.sort { (obj1, obj2) -> Bool in
//            return obj1.createTime > obj2.createTime
//        }
//
//        return (subFolderArr, subFileArr)

//    }
    
}
