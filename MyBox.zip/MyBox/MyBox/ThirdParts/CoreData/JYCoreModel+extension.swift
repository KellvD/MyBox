//
//  File.swift
//  MyBox
//
//  Created by Kellv on 2024/12/7.
//  Copyright © 2024 Kellv. 2012-2019. All rights reserved.
//

import Foundation
import CoreData
extension CoreFile {
    func copy(from file: JYFileInfo) {
        self.location = file.location
        self.createTime = Int64(file.createTime)
        self.fileId = Int16(file.fileId)
        self.fileText = file.fileText
        self.fileType = Int16(file.fileType.rawValue)
        self.folderId = Int16(file.folderId)
        self.height = Float(file.height)
        self.importTime = Int64(file.importTime)
        self.isGrade = file.isGrade
        self.markInfo = file.markInfo
        self.modifyTime = Int64(file.modifyTime)
        self.thumbPath = file.thumbPath
        self.timeLength = Float(Int16(file.timeLength))
        self.userId = Int16(file.userId)
        self.name = file.name
        self.path = file.path
        self.size = Int32(file.size)
    }
}

extension CoreUser {
    func copy(from user: JYUserInfo) {
        self.type = user.type.rawValue
        self.name = user.name
        self.pwd = user.pwd
        self.thumbPath = user.thumbPath
        self.userId = Int16(user.userId)
        self.validityTime = Int64(user.validityTime)
    }
}

extension CoreFolder {
    func copy(from folder: JYFolderInfo) {
        self.createTime = Int64(folder.createTime)
        self.folderId = Int16(folder.folderId)
        self.isLock = folder.isLock
        self.folderType = Int16(folder.folderType.rawValue)
        self.modifyTime = Int64(folder.modifyTime)
        self.name = folder.name
        self.userId = folder.userIds.map({ "\($0)" }).joined(separator: ",")
        self.path = folder.path
        self.superId = Int16(folder.superId)
        self.markInfo = folder.markInfo

    }
}

extension JYFileInfo {
    func fetch(from core: CoreFile) {
        self.location = core.location
        self.createTime = Int(core.createTime)
        self.fileId = Int(core.fileId)
        self.fileText = core.fileText
        self.fileType = NSFileType(rawValue: Int(core.fileType))
        self.folderType = NSFolderType(rawValue: Int(core.folderType))
        self.folderId = Int(core.folderId)
        self.height = core.height
        self.importTime = Int(core.importTime)
        self.isGrade = core.isGrade
        self.markInfo = core.markInfo
        self.modifyTime = Int(core.modifyTime)
        self.thumbPath = core.thumbPath
        self.timeLength = core.timeLength
        self.userId = Int(core.userId)
        self.name = core.name
        self.path = core.path
        self.size = Int(core.size)
    }
}

extension JYUserInfo {
    func fetch(from core: CoreUser) {
        if let type = core.type {
            self.type = JYUserType(rawValue: type) ?? .trmporary
        }
        self.name = core.name
        self.pwd = core.pwd
        self.thumbPath = core.thumbPath
        self.userId = Int(core.userId)
        self.validityTime = Int(core.validityTime)
    }
}

extension JYFolderInfo {
    func fetch(from core: CoreFolder) {
        self.createTime = Int(core.createTime)
        self.folderId = Int(core.folderId)
        self.isLock = core.isLock
        self.folderType = NSFolderType(rawValue: Int(core.folderType))
        self.modifyTime = Int(core.modifyTime)
        self.name = core.name
        self.userIds = (core.userId?.components(separatedBy: ",").compactMap { Int($0) })!
        self.path = core.path
        self.superId = Int(core.superId)
        self.markInfo = core.markInfo
    }
}
