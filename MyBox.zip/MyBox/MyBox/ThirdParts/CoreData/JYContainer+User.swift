//
//  JYContainer+User.swift
//  MyBox
//
//  Created by Kellv on 2024/12/7.
//  Copyright © 2024 Kellv. 2012-2019. All rights reserved.
//

import Foundation
import CoreData
extension JYContainer {
    public func insertUser(user: JYUserInfo) -> Int {
        
        let context = container.viewContext
        guard let core = NSEntityDescription.insertNewObject(forEntityName: "CoreUser",
                                                             into: context) as? CoreUser else {
           return -1
        }
        
        let userId = queryMaxUserId() + 1
        core.copy(from: user)
        core.userId = user.userId == ADMINUSERID ? Int16(ADMINUSERID) : Int16(userId)
        if context.hasChanges {
            do {
                try context.save()
                return userId
            } catch {
                print("insertUser - error:\(error)")
            }
        }
        return -1
    }
    
    public func queryMaxUserId() -> Int {
        let context = container.viewContext
        do {
            let cores = try context.fetch(fetchUserRequest)
            return cores.count
        } catch {
            print("queryMaxFileId - error:\(error)")
        }
        return 0
    }
    
    public func queryUser(pwd: String? = nil, name: String? = nil, userId: Int? = nil) -> JYUserInfo? {
        let context = container.viewContext
        if let pwd = pwd {
            fetchUserRequest.predicate = NSPredicate(format: "pwd = %@", pwd)
        }else if let name = name {
            fetchUserRequest.predicate = NSPredicate(format: "name = %@", name)
        }else if let userId = userId {
            fetchUserRequest.predicate = NSPredicate(format: "userId = %d", userId)
        }
        do {
            let cores = try context.fetch(fetchUserRequest)
            if let core = cores.first {
                let user = JYUserInfo()
                user.fetch(from: core)
                return user
            }
            return nil
        } catch {
            print("queryUser - error:\(error)")
        }
        return nil
    }
    
    public func queryAllUser(_ isContainRoot:Bool = false) -> [JYUserInfo] {
        var users: [JYUserInfo] = []
        let context = container.viewContext
        if !isContainRoot {
            fetchUserRequest.predicate = NSPredicate(format: "userId != %d", ROOTSUPERID)
        }
        do {
            let cores = try context.fetch(fetchUserRequest)
            for core in cores {
                let user = JYUserInfo()
                user.fetch(from: core)
                users.append(user)
            }
        } catch {
            print("queryAllUser - error:\(error)")
        }
        return users
    }
    
    public func updateUser(pwd: String? = nil,
                           name: String? = nil,
                           thumbPath: String? = nil,
                           validityTime: Int? = nil,
                           userId: Int) {
        
        let context = container.viewContext
        fetchUserRequest.predicate = NSPredicate(format: "userId = %@", userId)

        do {
            let cores = try context.fetch(fetchUserRequest)
            if let core = cores.first {
                if let pwd = pwd {
                    core.pwd = pwd
                }else if let name = name {
                    core.name = name
                }else if let thumbPath = thumbPath {
                    core.thumbPath = thumbPath
                }else if let validityTime = validityTime {
                    core.validityTime = Int64(validityTime)
                }
            }
            if context.hasChanges {
                try context.save()
            }
        } catch {
            print("updateUser - error:\(error)")
        }
    }
    
    public func  deleteUser(userId: Int) {
        let context = container.viewContext
        fetchUserRequest.predicate = NSPredicate(format: "userId = %d", userId)

        do {
            let cores = try context.fetch(fetchUserRequest)
            if let core = cores.first {
                context.delete(core)
            }
            if context.hasChanges {
                try context.save()
            }
        } catch {
            print("updateUser - error:\(error)")
        }
    }
}
