//
//  CDSQLModel.swift
//  MyBox
//
//  Created by changdong on 2020/5/1.
//  Copyright © 2019 baize. All rights reserved.
//

import UIKit

class CDUserInfo: NSObject {

    var userId = Int()
    var basePwd = String()
    var thumbPath:String?
    var isRoot: Bool = false
    var validityTime: Int = 0
    var name:String?
}

class CDSafeFolder: NSObject {

    var folderName = String()  // 文件夹名称
    var folderId = Int()       // 文件夹id
    var folderType: NSFolderType! // 文件夹类型
    var isLock = false           // 文件夹是否新建还是默认
    var fakeType = CDFakeType.invisible         // 文件夹访客可见不可见
    var createTime = Int()       // 文件夹创建时间
    var modifyTime = Int() // 修改时间
    var userId = Int()           // 预留，多账户使用
    var superId = Int()          // 多层级文件夹时顶级文件夹的ID
    var folderPath = String()    // 文件夹路径
    var isSelected: Bool = false // 不入库，作为判断文件操作时是否选中，出库时设置为false
}

class CDSafeFileInfo: NSObject {
   
    enum NSFileGrade: Int {
        case lovely   // 喜爱收藏
        case normal   // 普通
    }

    enum NSFileType: Int {
        case txt = 0
        case audio = 1
        case image = 2
        case video = 3
        case pdf = 4
        case ppt = 5
        case docx = 6
        case excel = 8
        case rtf = 9
        case gif = 10
        case zip = 11
        case live = 12
        case html = 13
        case other = 14
    }

    var fileId = Int()
    var folderId = Int()
    var fileSize = Int()
    var width = Double()
    var height = Double()
    var timeLength = Double()
    var createTime = Int() // 创建时间 相册，沙盒导入文件的创建时间
    var modifyTime = Int() // 修改时间
    var importTime = Int() // 导入时间
    var fileType: NSFileType!
    var fileName = String()
    var fileText = String()
    var thumbPath = String()
    var filePath = String()
    var markInfo = String()
    var createLocation = String()
    var userId = Int()
    var grade: Bool!
    var isSelected: Bool!
    var folderType: NSFolderType! // 文件所属大类
}

class CDMusicInfo: NSObject {

    var musicId = Int()
    var musicName = String()
    var musicMark = String()
    var musicTimeLength = Double()
    var musicClassId = Int()
    var userId = Int()
    var musicSinger = String()
    var musicPath = String()
    var musicImage = String()
}

class CDMusicClassInfo: NSObject {
    var classId = Int()
    var className = String()
    var classAvatar = String()
    var userId = Int()
    var classCreateTime = Int()
}

class CDAttendanceInfo: NSObject {
    var attendanceId = Int() // 日程Id
    var year = Int() // 事件拆分年 不入库
    var month = Int() // 事件拆分月 不入库
    var day = Int() // 事件拆分日 不入库
    var time = Int() // 年月日时分
    var title = String()
    var type = Int()
    var statue = Int()
}

class CDNovelInfo: NSObject {
    var novelName = String()
    var novelPath = String()
    var importTime = Int()
    var novelId = Int()
}

class CDChapterInfo: NSObject {
    var chapterName = String()
    var content = String()
    var charterId = Int()
}
class CDWebPageInfo: NSObject {
    enum CDSelectedStatus: Int {
        case yes // 选中
        case no  // 未选中
    }
    
    enum NSWebType: Int {
        case history = 0
        case normal = 1
        case lock = 2
    }

    var webId = Int()
    var createTime = Int() // 创建时间 相册，沙盒导入文件的创建时间
    var webType: NSWebType!
    var webName = String()
    var thumbPath = String()
    var iconImagePath = String()
    var webUrl = String()
    var userId = Int()
    var isSelected: CDSelectedStatus!
}
