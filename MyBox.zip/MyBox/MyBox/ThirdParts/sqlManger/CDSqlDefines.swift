//
//  CDSqlDefines.swift
//  MyBox
//
//  Created by changdong on 2021/9/18.
//  Copyright © 2018 changdong. All rights reserved.
//

import Foundation
import SQLite
let sqlFileName = "CDSQL.db"

let SafeFileInfo = Table("CDSafeFileInfo")
let UserInfo = Table("CDUserInfo")
let MusicInfo = Table("CDMusicInfo")
let MusicClassInfo = Table("CDMusicClassInfo")
let AttendanceInfo = Table("CDAttendanceInfo")
let NovelInfo = Table("CDNovelInfo")
let ChapterInfo = Table("CDChapterInfo")
let WebPageInfo = Table("CDWebPageInfo")

let db_id = Expression<Int>(value: "id")
var db_folderName = Expression<String>(value: "folderName")
var db_folderId = Expression<Int>(value: "folderId")
var db_folderType = Expression<Int>(value: "folderType")
var db_isLock = Expression<Int>(value: "isLock")
var db_fakeType = Expression<Int>(value: "fakeType")
var db_createTime = Expression<Int>(value: "createTime")
var db_modifyTime = Expression<Int>(value: "modifyTime")
var db_importTime = Expression<Int>(value: "importTime")
var db_createLocation = Expression<String>(value: "createLocation")
var db_folderPath = Expression<String>(value: "folderPath")
var db_fileId = Expression<Int>(value: "fileId")
var db_fileSize = Expression<Int>(value: "fileSize")
var db_width = Expression<Double>(value: "width")
var db_height = Expression<Double>(value: "height")
var db_timeLength = Expression<Double>(value: "timeLength")
var db_fileType = Expression<Int>(value: "fileType")
var db_fileName = Expression<String>(value: "fileName")
var db_fileText = Expression<String>(value: "fileText")
var db_thumbPath = Expression<String>(value: "thumbPath")
var db_filePath = Expression<String>(value: "filePath")
var db_grade = Expression<Int>(value: "grade")
var db_userId = Expression<Int>(value: "userId")
var db_markInfo = Expression<String>(value: "markInfo")
var db_basePwd = Expression<String>(value: "basePwd")
var db_fakePwd = Expression<String>(value: "fakePwd")

// MARK: musicInfo
var db_musicId = Expression<Int>(value: "musicId")
var db_musicName = Expression<String>(value: "musicName")
var db_musicMark = Expression<String>(value: "musicMark")
var db_musicTimeLength = Expression<Double>(value: "musicTimeLength")
var db_musicClassId = Expression<Int>(value: "musicClassId")
var db_musicSinger = Expression<String>(value: "musicSinger")
var db_musicPath = Expression<String>(value: "musicPath")
var db_musicImage = Expression<String>(value: "musicImage")
// MARK: musicClass
var db_classId = Expression<Int>(value: "classId")
var db_className = Expression<String>(value: "className")
var db_classAvatar = Expression<String>(value: "classAvatar")
var db_classCreateTime = Expression<Int>(value: "classCreateTime")
var db_superId = Expression<Int>(value: "superId")

// MARK: CDAttendanceInfo
var db_attendanceId = Expression<Int>(value: "attendanceId")
var db_time = Expression<Int>(value: "time")
var db_day = Expression<Int>(value: "day")
var db_month = Expression<Int>(value: "month")
var db_year = Expression<Int>(value: "year")
var db_title = Expression<String>(value: "title")
var db_type = Expression<Int>(value: "type")
var db_statue = Expression<Int>(value: "statue")

var db_novelName = Expression<String>(value: "novelName")
var db_novelPath = Expression<String>(value: "novelPath")
var db_novelId = Expression<Int>(value: "novelId")

var db_chapterName = Expression<String>(value: "chapterName")
var db_content = Expression<String>(value: "content")
var db_charterId = Expression<Int>(value: "charterId")


var db_webId = Expression<Int>(value: "webId")
var db_webType = Expression<Int>(value: "webType")
var db_webName = Expression<String>(value: "webName")
var db_webUrl = Expression<String>(value: "webUrl")
var db_iconImagePath = Expression<String>(value: "iconImagePath")
