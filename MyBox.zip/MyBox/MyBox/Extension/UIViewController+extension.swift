//
//  File.swift
//  MyBox
//
//  Created by Kellv on 2024/7/13.
//  Copyright © 2024 Kellv. 2012-2019. All rights reserved.
//


import UIKit

extension UIViewController {
    
    func push(to viewController: UIViewController) {
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    
    func present(_ viewController: UIViewController) {
        self.present(viewController, animated: true)
    }
    

    
    func alertSpaceWarn(alertType: DiskSpaceAlertType) {
        let message: String = alertType.rawValue

        let alert = UIAlertController(title: "警告".localize(), message: message, preferredStyle: .alert)

        alert.addAction(UIAlertAction(title: "否".localize(), style: .cancel, handler: { (_) in
        }))
        alert.addAction(UIAlertAction(title: "是".localize(), style: .default, handler: { (_) in

        }))
        self.present(alert, animated: true, completion: nil)
    }
}
