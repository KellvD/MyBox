//
//  UIlabel+Extension.swift
//  MyBox
//
//  Created by Kellv on 2024/11/24.
//  Copyright © 2024 Kellv. 2012-2019. All rights reserved.
//

import Foundation
import UIKit

extension UILabel {
    func set(titleColor:UIColor, font:UIFont) {
        self.textColor = titleColor
        self.font = font
    }
}
