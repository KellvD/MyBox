//
//  Base+extension.swift
//  MyBox
//
//  Created by Kellv on 2024/11/24.
//  Copyright © 2024 Kellv. 2012-2019. All rights reserved.
//

import Foundation

extension Int {
    var toBool: Bool {
        get { return self == 1 }
    }
}

extension Bool {
    var toInt:Int {
        get{ self ? 1 : 0 }
    }
}
