//
//  String+Path.swift
//  MyRule
//
//  Created by changdong on 2018/12/10.
//  Copyright © 2018 changdong. All rights reserved.
//

import Foundation
import AVFoundation

extension String {
    /**
     获取document路径
     */
    static func documentPath() -> String {
        let docPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        return docPath
    }

    /**
    判断路径是否存在，不存在创建
    */
    static func ensurePathAt(path: String) {
        let manager = FileManager.default
        if !manager.fileExists(atPath: path) {
            do {
                try manager.createDirectory(atPath: path, withIntermediateDirectories: true, attributes: nil)
            } catch {
                print("创建路径失败" + error.localizedDescription)
            }
        }
    }

    /**
    创建SafeRule路径
    */
    static func RootPath() -> String {
        let docpath = documentPath()
        let userPath = (docpath as NSString).appendingPathComponent("SafeRule")
        ensurePathAt(path: userPath)
        return userPath
    }

    /**
    删除SafeRulek路径
    */
    static func deleteRootPath() {
        let docpath = documentPath()
        let userPath = (docpath as NSString).appendingPathComponent("SafeRule")
        if FileManager.default.fileExists(atPath: userPath) {
            do {
                try FileManager.default.removeItem(atPath: userPath)
            } catch {
            }
        }
    }

    // MARK: 图片路径
    @discardableResult
    static func ImagePath() -> String {
        let path = (RootPath() as NSString).appendingPathComponent("Images")
        ensurePathAt(path: path)
        return path
    }
    
    @discardableResult
    static func WebThumpFile() -> String {
        let path = (RootPath() as NSString).appendingPathComponent("web thump")
        ensurePathAt(path: path)
        return path
    }
    
    // 图片压缩路径
    static func thumpImagePath() -> String {
        let path = (ImagePath() as NSString).appendingPathComponent("ThumbImages")
        ensurePathAt(path: path)
        return path
    }
    
    static func avatarThumbPath() -> String {
        let path = (RootPath() as NSString).appendingPathComponent("avatarThumb")
        ensurePathAt(path: path)
        return path
    }

    

    // MARK: 音频
    static func AudioPath() -> String {
        let path = (RootPath() as NSString).appendingPathComponent("Audio")
        ensurePathAt(path: path)
        return path
    }

    // MARK: 视频
    @discardableResult
    static func VideoPath() -> String {
        let path = (RootPath() as NSString).appendingPathComponent("Video")
        ensurePathAt(path: path)
        return path
    }
    // 视频第一帧缩略图路径
    static func thumpVideoPath() -> String {
        let path = (VideoPath() as NSString).appendingPathComponent("ThumpVideo")
        ensurePathAt(path: path)
        return path
    }

    // MARK: Other
    @discardableResult
    static func OtherPath() -> String {
        let path = (RootPath() as NSString).appendingPathComponent("Other")
        ensurePathAt(path: path)
        return path
    }
    // MARK: Music
    @discardableResult
    static func MusicPath() -> String {
        let path = (RootPath() as NSString).appendingPathComponent("Music")
        ensurePathAt(path: path)
        return path
    }
    static func MusicImagePath() -> String {
        let path = (RootPath() as NSString).appendingPathComponent("Music/Image")
        ensurePathAt(path: path)
        return path
    }

    static func NovelPath() -> String {
        let path = (RootPath() as NSString).appendingPathComponent("Novel")
        ensurePathAt(path: path)
        return path
    }

    func appendingFormat(_ format: NSString, _ args: CVarArg...) -> NSString {
        let appen = self.AsNSString().appendingFormat(format, args)
        return appen
    }

    func appendingPathComponent(str: String) -> String {
        let appen = self.AsNSString().appendingPathComponent(str)
        return appen
    }

    func AsNSString() -> NSString {
        return (self as NSString)
    }

    func create() {
        String.ensurePathAt(path: self)
    }
    /**
    移除后缀名
    */
    func removeSuffix() -> String {
        let string = self.AsNSString().deletingPathExtension
        return string
    }

    /**
    删除文件
    */
    func delete() {
        let manager = FileManager.default
        if manager.fileExists(atPath: self) {
            do {
                if self.hasPrefix(String.RootPath()) {
                    try manager.removeItem(atPath: self)
                } else {
                    let path = String.RootPath().appendingPathComponent(str: self)
                    try manager.removeItem(atPath: path)
                }

            } catch {
                CDPrintManager.log("文件删除失败", type: .WarnLog)
            }
        }
    }

    // 相对路径
    var relativePath: String {
        get {
            let array: [String] = self.components(separatedBy: String.RootPath())
            let tempString: String = array.last!
            return tempString
        }
    }

    var absolutePath: String {
        get {
            let tempString = String.RootPath().appendingPathComponent(str: self)
            return tempString
        }
    }
    
    var thumpPath: String {
        get {
            let tempString = self.appendingPathComponent(str: "thump")
            return tempString
        }
    }
    
    /**
     获取完整的文件名
     */
    var lastPathComponent: String {
        get {
            let last = self.AsNSString().lastPathComponent
            return last
        }
    }

    /**
    获取不带后缀的文件名
    */
    var fileName: String {
        get {
            let fileLastPath = self.lastPathComponent
            let fileName = fileLastPath.removeSuffix().removePercentEncoding
            return fileName
        }
    }

    /**
    拼接文件完整路径
    */
    var rootPath: String {
        get {
            if !self.hasPrefix(String.RootPath()) {
                return String.RootPath().appendingPathComponent(str: self)
            }
            return self
        }
    }

    /**
    路径转URL
    */
    var pathUrl: URL {
        get {
            return URL(fileURLWithPath: self)
        }
    }
    
    var stringUrl: URL? {
        get {
            return URL(string: self)
        }
    }
    /**
     获取文件后缀
    */
    var suffix: String {

        get {
            let string = self.AsNSString().pathExtension
            return string
        }

    }
    /**
     文件信息
    */
    var fileAttribute:(fileSize: Int, createTime: Int) {
        get {
            var fileSize: Int = 0
            var createTime: Int = 0
            if FileManager.default.fileExists(atPath: self) {
                do {
                    let attr = try FileManager.default.attributesOfItem(atPath: self)
                    fileSize = attr[FileAttributeKey.size] as! Int
                    let creationDate = attr[FileAttributeKey.creationDate] as!Date
                    createTime = Int(creationDate.timeIntervalSince1970 * 1000)

                } catch {

                }
            }
            return (fileSize, createTime)
        }

    }
    
    var folderSize: Int{
        var isDir: ObjCBool = false
        let manager = FileManager.default
        var fileSize: Int = 0
        if manager.fileExists(atPath: self, isDirectory: &isDir) {
            if isDir.boolValue {
                let fileArr = manager.subpaths(atPath: self)!
                fileArr.forEach { (path) in
                    let allPath = self + "/" + path
                    fileSize = fileSize + allPath.fileAttribute.fileSize
                }
                return fileSize
            }
        }
        return fileAttribute.fileSize
    }

    var removeSpaceAndNewline: String {
        get {
            return self.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        }
    }
    
    var removePercentEncoding: String {
        get {
            let string = self.AsNSString().removingPercentEncoding
            return string!
        }
    }
    /**
    根据文件后缀判断文件类型
    */
    var fileType: NSFileType {
        let tmp = self.uppercased()
        if ["PDF", "PDFX", "PPT", "PPTX", "KEY"].contains(tmp) {
            return .pdf
        } else if ["DOC", "DOCX", "DOCUMENT", "PAGES"].contains(tmp) {
            return .docx
        } else if tmp == "TXT" {
            return .txt
        } else if ["XLS", "XLSX", "NUMBERS"].contains(tmp) {
            return .excel
        } else if tmp == "RTF" {
            return .rtf
        } else if tmp == "GIF" {
            return .gif
        } else if ["PNG", "JPG", "HEIC", "JPEG", "BMP", "TIF", "PCD", "MAC", "PCX", "DXF", "CDR"].contains(tmp) {
            return .image
        } else if ["MP3", "WAV", "VOC", "M4A", "M4R", "M4V", "AAC", "CAF", "CDA", "MID", "RAM", "RMX", "VQF", "AIFF", "SND", "SVX", "AMR"].contains(tmp) {
        return .audio
        } else if ["MOV", "MP4", "AVI", "MPG", "M2V", "VOB", "ASF", "WMF", "RMVB", "RM", "DIVX", "MKV"].contains(tmp) {
            return .video
        } else if ["ZIP", "RAR", "7-ZIP", "ACE", "ARJ", "BV2", "CAD", "GZIP", "ISO", "JAR", "LZH", "TAR", "UUE", "XZ"].contains(tmp) {
            return .zip
        } else if ["HTML"].contains(tmp) {
            return .html
        } else {
            return .other
        }

    }
}
