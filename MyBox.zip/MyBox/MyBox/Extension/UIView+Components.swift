//
//  UIView+Components.swift
//  MyBox
//
//  Created by dong chang on 2023/6/8.
//  Copyright © 2023 (c) Huawei Technologies Co., Ltd. 2012-2019. All rights reserved.
//

import UIKit
extension UIView {
    private static let padding: CGFloat = 20
    
    func addBlurView(frame: CGRect = CGRect(x: 0, y: 0, width: CDSCREEN_WIDTH, height: CDSCREEN_HEIGTH)) {
        let backGroundView = UIView(frame: frame)
        backGroundView.isUserInteractionEnabled = true
        backGroundView.alpha = 0.3
        addSubview(backGroundView)
        
        // 毛玻璃效果
        let blurEffect = UIBlurEffect(style: .dark)
        let effectView = UIVisualEffectView(effect: blurEffect)
        effectView.frame = backGroundView.bounds
        backGroundView.addSubview(effectView)
        UIDevice.keyWindow().addSubview(self)
        UIDevice.keyWindow().bringSubviewToFront(self)
        UIDevice.keyWindow().becomeFirstResponder()
    }
}
