//
//  UITableViewCell+extension.swift
//  MyBox
//
//  Created by Kellv on 2024/12/14.
//  Copyright © 2024 Kellvv   . All rights reserved.
//

import Foundation
import UIKit
extension UITableViewCell {
    
    func redraw(tableView: UITableView,
                indexPath: IndexPath) {
        let radius = 12.0
        self.backgroundColor = .clear
        let normalLayer = CAShapeLayer()
        let selectLayer = CAShapeLayer()
        let bounds = self.bounds.insetBy(dx:16.0, dy:0)
        let rowNum = tableView.numberOfRows(inSection: indexPath.section)
        var bezierPath:UIBezierPath
        if(rowNum==1) {
            bezierPath = UIBezierPath(roundedRect: bounds, byRoundingCorners: .allCorners, cornerRadii:CGSize(width: radius, height: radius))
        }else{
            if(indexPath.row==0) {
                bezierPath = UIBezierPath(roundedRect: bounds, byRoundingCorners:[UIRectCorner.topLeft,UIRectCorner.topRight], cornerRadii:CGSize(width: radius, height: radius))
            }else if(indexPath.row==rowNum-1) {
                bezierPath = UIBezierPath(roundedRect: bounds, byRoundingCorners: [UIRectCorner.bottomLeft,UIRectCorner.bottomRight], cornerRadii:CGSize(width: radius, height: radius))
            }else{
                bezierPath = UIBezierPath(rect: bounds)
            }
        }
        normalLayer.path = bezierPath.cgPath
        selectLayer.path = bezierPath.cgPath
        let nomarBgView = UIView(frame: bounds)
        normalLayer.fillColor = UIColor.white.cgColor
        nomarBgView.layer.insertSublayer(normalLayer, at:0)
        nomarBgView.backgroundColor = .clear
        self.backgroundView = nomarBgView
        
        let selectBgView = UIView(frame: bounds)
        selectLayer.fillColor = UIColor.lightGray.cgColor
        selectBgView.layer.insertSublayer(selectLayer, at:0)
        self.selectedBackgroundView = selectBgView
    }
}
