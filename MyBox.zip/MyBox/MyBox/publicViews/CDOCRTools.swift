//
//  CDOCRTools.swift
//  PDF
//
//  Created by Kellv on 2024/4/27.
//

import Foundation
import UIKit
import Vision
class CDOCRTools {
    
    static func ocrText(in image: UIImage, recognitionLanguages: [String] = Locale.availableIdentifiers, textHandler:@escaping ([String],String?)->Void) {
        DispatchQueue.global().async {
            
            let request = VNRecognizeTextRequest { request, error in
                var textArr: [String] = []
                if let results = request.results as? [VNRecognizedTextObservation] {
                    let recognizedStrings = results.compactMap { observation in
                        
                        return observation.topCandidates(1).first?.string
                    }
                    textArr.append(contentsOf: recognizedStrings)
                }
                DispatchQueue.main.async {
                    textHandler(textArr, nil)
                    CDPrintManager.log("图片识别文字:\(textArr)", type: .InfoLog)
                }
                
            }
            
            request.recognitionLanguages = recognitionLanguages
            
            request.recognitionLevel = .accurate
            request.usesLanguageCorrection = true
            
            guard let cgimage = image.cgImage else {
                DispatchQueue.main.async {
                    CDHUDManager.shared.showText("This image does not support text recognition".localize())
                    textHandler([], "This image does not support text recognition".localize())
                }
                return
            }
            
            let requesthandler = VNImageRequestHandler(cgImage: cgimage, options: [:])
            do {
                try requesthandler.perform([request])
                
            } catch {
                CDPrintManager.log("图片识别文字异常:\(error.localizedDescription)", type: .ErrorLog)
            }
        }
    }
    
}
