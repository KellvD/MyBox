//
//  CDUserDetailViewController.swift
//  MyBox
//
//  Created by Kellv on 2024/12/7.
//  Copyright © 2024 Kellv. 2012-2019. All rights reserved.
//

import UIKit
import CDMediaPicker


class CDUserDetailViewController: CDBaseAllViewController {
    var user = JYUserInfo()
    var isAdd: Bool = false
    var folderArr: [JYFolderInfo] = []
    private var slectedType:CDOptions = .userAvatar
    private var tableview: UITableView!
    private lazy var titleArr:[[CDOptions]] = {
        if self.user.type == .trmporary && !isAdd {
            return [[.userAvatar,.userName],[.userType,.userPwd]]
        }else {
            return [[.userAvatar,.userName],[.userType,.userValidityTime, .userPwd]]
        }
    }()
    
    lazy var picker: CDSelectItemsAlert = {
        let picker = CDSelectItemsAlert()
        picker.contentBlock = {[weak self] content in
            guard let self = self else {
                return
            }
            
            if slectedType == .userType {
                user.type = JYUserType(rawValue: content)!
            }else if slectedType == .userValidityTime {
//                user.type = JYUserType(rawValue: content)

            }
            self.tableview.reloadData()

        }
        return picker
    }()
    
    lazy var inputAlert: CDInputAlert = {
        let alert = CDInputAlert(isMultipleLines: false)
        alert.actionHandler = {[weak self] content in
            guard let self = self else {
                return
            }
            user.name = content
            self.tableview.reloadData()
        }
        return alert
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = isAdd ? "New Account" : user.name
        let buttonTitle = isAdd ? "Create" : "Delete"
        let button = UIButton(frame: CGRect(x: 16, y: CDViewHeight - UIDevice.safeAreaBottom() - 48, width: CDSCREEN_WIDTH - 32, height: 48), text: buttonTitle.localize(), textColor: .white, target: self, function: #selector(onHandlerUserAction))
        button.layer.cornerRadius = 14
        button.backgroundColor = .customBlue
        view.addSubview(button)
        
        tableview = UITableView(frame: CGRect(x: 0, y: 0, width: CDSCREEN_WIDTH, height: button.minY - 10), style: .grouped)
        tableview.separatorStyle = .none
        tableview.delegate = self
        tableview.dataSource = self
        tableview.sectionHeaderHeight = SECTION_SPACE
        tableview.sectionFooterHeight = 0.01
        tableview.tableHeaderView = nil
        tableview.tableFooterView = nil
        tableview.register(CDSwitchCell.self, forCellReuseIdentifier: "UserDEtail_id")
        tableview.register(CDFileTableViewCell.self, forCellReuseIdentifier: "UserDEtail_folder_id")

        view.addSubview(tableview)
        initData()
    }
    
    func initData() {
        if isAdd {
            return
        }
        let dataArr = JYContainer.shared.queryAllFolder(userId: user.userId)
        folderArr = dataArr.flatMap({ $0 })
        tableview.reloadData()
    }
    
    @objc func onHandlerUserAction() {
        if isAdd {
//            if (user.name == nil) {
//                CDHUDManager.shared.showText("Please set user name".localize())
//                return
//            }else if (user.pwd == nil) {
//                CDHUDManager.shared.showText("Please set user password".localize())
//                return
//            }
            user.isRoot = false
            user.validityTime = GetTimestamp()
            _ = JYContainer.shared.insertUser(user: user)
            CDHUDManager.shared.showText("Create Success!".localize())
            self.navigationController?.popViewController(animated: true)

        }else {
            var count = 0
            for folder in folderArr {
                if folder.userIds.count > 1 {
                    count += 1
                }
            }
            var title = "Are you sure you want to do this?".localize()
            if count > 0 {
                title = "This account has %d exclusive folders, and the exclusive folders will also be deleted after the account is deleted. Are you sure you want to do this?".localize("\(count)")
            }
            
            alert(title: "Warning".localize(),message: title,defaultTitle: "Sure") { _ in
                if count == 0 {
                    JYContainer.shared.deleteUser(userId: self.user.userId)
                }else {
                    JYContainer.shared.deleteUser(userId: self.user.userId)
                    for folder in self.folderArr {
                        if folder.userIds.count == 1 {
                            JYContainer.shared.deleteFolder(folderId: folder.folderId)
                            JYContainer.shared.deleteFile(folderId: folder.folderId)
                        }else {
                            folder.userIds.removeAll { $0 == self.user.userId }
                            JYContainer.shared.updateFolder(userIds: folder.userIds.map({ "\($0)" }).joined(separator: ","),folderId: folder.folderId)
                        }
                    }
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
    
    func selectedAvatar() {
        checkPermission(type: .library) { (isAllow) in
             if isAllow {
                DispatchQueue.main.async {
                    // 保持屏幕常亮
                    UIApplication.shared.isIdleTimerDisabled = true

                    let cdPicker = CDMediaPickerViewController(isVideo: false)
                    CDSignalTon.shared.customPickerView = cdPicker
                    cdPicker.pickerDelegate = self
                    cdPicker.modalPresentationStyle = .fullScreen
                    self.present(cdPicker, animated: true, completion: nil)

                }

             } else {
                openPermission(type: .library, viewController: self)
            }
        }
    }
  
}


extension CDUserDetailViewController: UITableViewDelegate,UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return section == 2 ? folderArr.count : titleArr[section].count
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 2 {
            return 56
        }
        if indexPath.section == 0 && indexPath.row == 0 {
            return 86
        }
        
        return CELL_HEIGHT
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 2 {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "UserDEtail_folder_id", for: indexPath) as! CDFileTableViewCell
            let folder = folderArr[indexPath.row]
            cell.setConfigFolderData(folder: folder)
            return cell
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserDEtail_id") as! CDSwitchCell
        let option = self.titleArr[indexPath.section][indexPath.row]
        cell.titleLabel.text = option.rawValue.localize()
        if option == .userAvatar {
            cell.avatarView.image = user.thumbPath?.absolutePath.image ?? "mine_normal".image
        }else if option == .userName {
            cell.valueLabel.text = user.name
        }else if option == .userType {
            cell.valueLabel.text = user.type.rawValue
        }else if option == .userValidityTime {
            cell.valueLabel.text = "user.validityTime"
        }
        cell.accessoryType = option != .userValidityTime ? .disclosureIndicator : .none
        cell.avatarView.isHidden = option != .userAvatar
        cell.valueLabel.isHidden = option == .userAvatar

        cell.separatorLineIsHidden = indexPath.row == titleArr[indexPath.section].count - 1
        return cell
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.section == 2 {
            return
        }
        cell.redraw(tableView: tableView,indexPath: indexPath)

    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath.section == 2 {
           
        }else {
            let option = self.titleArr[indexPath.section][indexPath.row]
            slectedType = option
            if option == .userValidityTime && isAdd {
                self.picker.dataArr = ["One Day","One Week","One Mouth"]
                self.picker.show()
            }else if option == .userType {
                self.picker.dataArr = ["One Day","One Week","One Mouth"]
                self.picker.show()
            }else if option == .userName {
                self.inputAlert.show()
            }else if option == .userAvatar {
                selectedAvatar()
            }
            
        }
    }
}


extension CDUserDetailViewController: CDMediaPickerViewControllerDelegate {
    func onMediaPickerDidCancle(picker: CDMediaPicker.CDMediaPickerViewController) {
        DispatchQueue.main.async {
            picker.dismiss(animated: true)
        }
    }
    
    func onMediaPickerDidFinished(picker: CDMediaPickerViewController, data: [String: Any?], index: Int, totalCount: Int) {

        let fileName = data["fileName"] as! String
        let imageType = data["imageType"] as! String

        let thumbPath = String.avatarThumbPath().appendingPathComponent(str: "\(fileName)")
        var image: UIImage
        if imageType == "gif"{
            let data = data["file"] as! Data
            image = UIImage(data: data)!
            do {
                try data.write(to: thumbPath.pathUrl)
            } catch {
                return
            }
        } else {

            image = data["file"] as! UIImage
            let smallImage = image.compress(maxWidth: 1280)
            do {
                let imageData = smallImage.jpegData(compressionQuality: 0.5)
                try imageData?.write(to: thumbPath.pathUrl)
            } catch {
                return
            }

        }
        user.thumbPath = thumbPath.relativePath
        DispatchQueue.main.async {
            picker.dismiss(animated: true)
            self.tableview.reloadData()
        }
    }

}
