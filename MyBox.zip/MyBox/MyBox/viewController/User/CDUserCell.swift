//
//  CDUserCell.swift
//  MyBox
//
//  Created by Kellv on 2024/12/7.
//  Copyright © 2024 Kellv. 2012-2019. All rights reserved.
//

import UIKit

class CDUserCell: UITableViewCell {

    @IBOutlet weak var iconView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var vipButton: UIButton!
    
    @IBOutlet weak var titleTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var moreButton: UIButton!
    var eventCallBack:(()->Void)?
    override func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = .white
        self.layer.cornerRadius = 8
        
        iconView.layer.cornerRadius = 9
        titleLabel.textColor = .titleColor
//        vipButton.textColor = .subTitleColor
        
        titleLabel.font = .titleFont
//        vipButton.font = .subTitleFont
    }

    var isListStyle:Bool! {
        didSet {
            moreButton.isHidden = !isListStyle
            vipButton.isHidden = isListStyle
            titleTopConstraint.constant = isListStyle ? 13 : 0
        }
    }
    
    func loadData(user: JYUserInfo) {
        if let image = user.thumbPath?.absolutePath.image {
            iconView.image = image
        }else {
            iconView.image = "safe_select".image
        }
        
        titleLabel.text = user.name
//        timeLabel.text = GetTimeFormat(user.validityTime)
    }
    
    @IBAction func onMoreAction(_ sender: Any) {
        if let eventCallBack = eventCallBack {
            eventCallBack()
        }
    }
}
