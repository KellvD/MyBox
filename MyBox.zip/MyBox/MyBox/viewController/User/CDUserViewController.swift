//
//  CDUserViewController.swift
//  MyBox
//
//  Created by Kellv on 2024/12/7.
//  Copyright © 2024 Kellv. 2012-2019. All rights reserved.
//

import UIKit

class CDUserViewController: UIViewController {
    private var tableview: UITableView!
    private let optionArr = ["Account","Restore","Terms","Privacy Policy","Share App"]
    private var commonData: [CDSettingMode] = []
    override func viewDidLoad() {
        super.viewDidLoad()

        tableview = UITableView(frame: CGRect(x: 0, y: 0, width: CDSCREEN_WIDTH, height: CDSCREEN_HEIGTH), style: .grouped)
        tableview.separatorStyle = .none
        tableview.delegate = self
        tableview.dataSource = self
        
        tableview.register(UINib(nibName: "CDUserCommonXib", bundle: nil), forCellReuseIdentifier: "CDUserCell_id")
        tableview.register(CDSwitchCell.self, forCellReuseIdentifier: "UserDEtail_id")

        view.addSubview(tableview)
        
    }
    
    func initCommonData() {
        
    }
    
}

extension CDUserViewController: UITableViewDataSource,UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 2 {
            return optionArr.count
        }
        return 1
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            return 86
        }
        
        return CELL_HEIGHT
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return SECTION_SPACE
    }

    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.01
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }

    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "CDUserCell_id", for: indexPath) as! CDUserCell
            cell.selectionStyle = .none
            cell.isListStyle = false
            cell.loadData(user: JYCurrentUser())
            return cell
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserDEtail_id", for: indexPath) as! CDSwitchCell
              
        if indexPath.section == 1 {
            cell.titleLabel.text = "Common".localize()
            cell.separatorLineIsHidden = true

        }else {
            let op = optionArr[indexPath.row]
            cell.titleLabel.text = op
            cell.separatorLineIsHidden = indexPath.row == optionArr.count - 1
        }

        return cell
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.redraw(tableView: tableView, indexPath: indexPath)
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath.section == 0 {
            let vc = CDUserDetailViewController()
            vc.user = CDSignalTon.shared.userInfo
            vc.hidesBottomBarWhenPushed = true
            self.push(to: vc)
        }
        if indexPath.section == 1 {
            let opvc = CDOptionViewController()
            opvc.title = "Common".localize()
            opvc.options = [[.commonTheme,.commonAppIcon,.commonTransition]]
            self.navigationController?.pushViewController(opvc, animated: true)
        }else {
            let item = optionArr[indexPath.row]
            if item == "Restore Purchases" {
//                PHVipKit.viewController = self
//                PHVipKit.restoreProduct { _ in}
            }else if item == "Terms & Conditions" {
//                let vc = CDPrivateViewController()
//                vc.url = termsUs
//                vc.titleName = item.localize()
//                vc.modalPresentationStyle = .fullScreen
//                self.present(vc, animated: true)
            }else if item == "Privacy Policy" {
//                let vc = CDPrivateViewController()
//                vc.url = privateUrl
//                vc.titleName = item.localize()
//                vc.modalPresentationStyle = .fullScreen
//                self.present(vc, animated: true)
            }else if item == "Share App" {
                let url = URL(string: appStroeLink)
                let activityVC = UIActivityViewController(activityItems: [GetAppName(), url as Any], applicationActivities: nil)
                activityVC.completionWithItemsHandler = {(_, complete, _, error) -> Void in
                }
                self.present(activityVC, animated: true, completion: nil)
            }
        }
    }
}
