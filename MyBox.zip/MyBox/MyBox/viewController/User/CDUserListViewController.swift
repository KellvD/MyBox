//
//  CDUserListViewController.swift
//  MyBox
//
//  Created by Kellv on 2024/12/7.
//  Copyright © 2024 Kellv. 2012-2019. All rights reserved.
//

import UIKit

class CDUserListViewController: UIViewController {
    private var isReloadData = false
    var dataArr: [JYUserInfo] = []
    private var tableview: UITableView!

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if isReloadData {
            initData()
            isReloadData = false
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        isReloadData = true
        tableview = UITableView(frame: CGRect(x: 0, y: 0, width: CDSCREEN_WIDTH, height: CDSCREEN_HEIGTH), style: .grouped)
        tableview.separatorStyle = .none
        tableview.delegate = self
        tableview.dataSource = self
        tableview.rowHeight = 86
        tableview.sectionHeaderHeight = SECTION_SPACE
        tableview.sectionFooterHeight = 0.01
        tableview.tableHeaderView = nil
        tableview.tableFooterView = nil
        tableview.register(CDUserCell.self, forCellReuseIdentifier: "CDUserCell_user")
        view.addSubview(tableview)
        
        let addBtn = UIButton(type: .custom)
        addBtn.setImage(UIImage(named: "Add Files Folder"), for: .normal)
        addBtn.addTarget(self, action: #selector(addUserAction), for: .touchUpInside)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: addBtn)
        
    }
    
    func initData() {
        dataArr = JYContainer.shared.queryAllUser()
        tableview.reloadData()
    }
    
    @objc func addUserAction() {
        isReloadData = true
        let vc = CDUserDetailViewController()
        vc.isAdd = true
        self.navigationController?.pushViewController(vc, animated: true)
    }

}

extension CDUserListViewController: UITableViewDataSource,UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        dataArr.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1

    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CDUserCell_user", for: indexPath) as! CDUserCell
        cell.selectionStyle = .none
        cell.isListStyle = true
        let user = dataArr[indexPath.section]
        cell.loadData(user: user)
        return cell
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.redraw(tableView: tableView, indexPath: indexPath)
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let user = dataArr[indexPath.section]
        let vc = CDUserDetailViewController()
        vc.user = user
        self.push(to: vc)
    }
}
