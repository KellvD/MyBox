//
//  CDWebViewController.swift
//  MyBox
//
//  Created by Kellv on 2024/8/16.
//  Copyright © 2024 (c) Huawei Technologies Co., Ltd. 2012-2019. All rights reserved.
//

import UIKit

class CDWebViewController: CDBaseAllViewController,UICollectionViewDelegate,
                           UICollectionViewDataSource,
                           UICollectionViewDelegateFlowLayout {
    private var collectionView: UICollectionView!
    private var dataArr: [CDWebPageInfo] = []
    private var sitArr: [CDWebPageInfo] = []
    
    private var isNeedReloadData = false
    private var isInterPop = false
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if isNeedReloadData {
            isNeedReloadData = false
            refreshDBData()
        }
    }
    
    
    deinit{
        NotificationCenter.default.removeObserver(self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addPageAction))
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        collectionView = UICollectionView(frame: CGRect(x: 0, y: 0, width: CDSCREEN_WIDTH, height: CDViewHeight), collectionViewLayout: layout)
        collectionView.register(UINib(nibName: "CDWebPageCell", bundle: nil), forCellWithReuseIdentifier: "CDWebPageCell")
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = UIColor.white
        view.addSubview(collectionView)
        refreshDBData()
        NotificationCenter.default.addObserver(self, selector: #selector(refreshDBData), name: NSNotification.Name("updateWebPage"), object: nil)
        
        
    }
    
    
    @objc func refreshDBData() {
        dataArr = JYContainer.shared.queryAllWebPage(type: .normal)
        sitArr = JYContainer.shared.queryLocSiteWebPage()
        collectionView.reloadData()
    }
    
    @objc func addPageAction() {
        func addNewPage() {
            self.isNeedReloadData = true
            
            let vc = CDWebPageViewController()
            vc.isAdd = true
            vc.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(vc, animated: true)
            
        }
        
        addNewPage()
        
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSizeMake((CDSCREEN_WIDTH - 12 * 2 - 32)/2.0, 194)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return section == 0 ? 12 : 32
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return section == 0 ? 0 : 24
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 12, left: 12, bottom: 12, right: 12)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CDWebPageCell", for: indexPath) as! CDWebPageCell
        let web = dataArr[indexPath.item]
        cell.actionBlock = {[weak self] in
            guard let self = self else {
                return
            }
            self.dataArr.remove(at: indexPath.item)
            self.collectionView.reloadData()
            JYContainer.shared.updateWebPagewWebType(type: .history, webId: web.webId)
            
        }
        cell.loadData(file: web, isBatchEdit: false)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        
        let web = dataArr[indexPath.item]
        let vc = CDWebPageViewController()
        vc.hidesBottomBarWhenPushed = true
        vc.file = web
        self.navigationController?.pushViewController(vc, animated: true)
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
}
