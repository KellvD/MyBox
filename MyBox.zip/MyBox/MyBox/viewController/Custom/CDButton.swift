//
//  CDButton.swift
//  Figma
//
//  Created by Kellv on 2024/11/7.
//

import UIKit

class CDButton: UIButton {

    var imageV: UIImageView!
    var textLabel:UILabel!
    var imageString:String!
    override init(frame: CGRect) {
        super.init(frame: frame)
        imageV = UIImageView(frame: CGRect(x: self.width/2.0 - 10, y: 16, width: 20, height: 20))
        imageV.tag = 1
        self.addSubview(imageV)
        
        
        textLabel = UILabel(frame: CGRect(x: 0, y: imageV.maxY + 4, width: self.width, height: 16))
        textLabel.font = UIFont.systemFont(ofSize: 10,weight: .regular)
        textLabel.textColor = .black
        textLabel.tag = 2
        textLabel.textAlignment = .center
        self.addSubview(textLabel)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func load(title: String, imageString: String){
        textLabel.text = title
        imageV.image = imageString.image
        self.imageString = imageString
    }
    
    override var isSelected: Bool {
        didSet {
//            textLabel.textColor = isSelected ? "287EEB".color : .black
//            imageV.image = isSelected ? "\(imageString!)_select".image : imageString.image
        }

    }
}
