//
//  CDRenameAlert.swift
//  MyBox
//
//  Created by Kellv on 2024/11/18.
//  Copyright © 2024 Kellv. 2012-2019. All rights reserved.
//

import UIKit

class CDInputAlert: UIView {
   
    var actionHandler:((String) -> Void)?
    
    private var popView:CDInputNib!
    init(frame: CGRect = CGRect(x: 0, y: 0, width: CDSCREEN_WIDTH, height: CDSCREEN_HEIGTH), isMultipleLines:Bool = false) {
        super.init(frame: frame)
        addBlurView()
        let tap = UITapGestureRecognizer(target: self, action: #selector(dismiss))
        self.addGestureRecognizer(tap)
        
        let xib = UINib(nibName: "CDInputNib", bundle: nil)
        popView = xib.instantiate(withOwner: self, options: nil).first as? CDInputNib
        if isMultipleLines {
            popView.frame = CGRect(x: 46, y: (CDSCREEN_HEIGTH - 268)/2.0, width: CDSCREEN_WIDTH - 46 * 2, height: 268)
            popView.ranameLabel.text = "Rename".localize()
        }else {
            popView.frame = CGRect(x: 46, y: (CDSCREEN_HEIGTH - 188)/2.0, width: CDSCREEN_WIDTH - 46 * 2, height: 188)
            popView.ranameLabel.text = "Remark".localize()

        }
        popView.inputFile.isHidden = isMultipleLines
        popView.textView.isHidden = !isMultipleLines
        popView.countLabel.isHidden = !isMultipleLines
        popView.layer.cornerRadius = 8
        popView.actionHandler = {[weak self] content in
            guard let self = self else{
                return
            }
            if let content = content,
               let actionHandler = actionHandler {
                actionHandler(content)
            }
            dismiss()
        }
        self.addSubview(popView)
    }
    
    var isMultipleLines: Bool = false {
        didSet {
            if isMultipleLines {
                popView.frame = CGRect(x: 46, y: (CDSCREEN_HEIGTH - 268)/2.0, width: CDSCREEN_WIDTH - 46 * 2, height: 268)
                popView.ranameLabel.text = "Rename".localize()
            }else {
                popView.frame = CGRect(x: 46, y: (CDSCREEN_HEIGTH - 188)/2.0, width: CDSCREEN_WIDTH - 46 * 2, height: 188)
                popView.ranameLabel.text = "Remark".localize()

            }
            popView.inputFile.isHidden = isMultipleLines
            popView.textView.isHidden = !isMultipleLines
            popView.countLabel.isHidden = !isMultipleLines
        }
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func show() {
        UIView.animate(withDuration: 0.25) {
            self.minY = 0
        }
    }
    
    @objc func dismiss() {
        UIView.animate(withDuration: 0.25) {
            self.minY = CDSCREEN_HEIGTH
        }
    }
}

class CDInputNib: UIView,UITextFieldDelegate,UITextViewDelegate {
    @IBOutlet weak var cancelbtn: UIButton!
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var inputFile: UITextField!
    @IBOutlet weak var ranameLabel: UILabel!
    @IBOutlet weak var sureBtn: UIButton!
    @IBOutlet weak var countLabel: UILabel!
    var actionHandler:((String?) -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        ranameLabel.textColor = .black
        ranameLabel.font = .small
        
        countLabel.textColor = .gray
        countLabel.font = .midSmall
        
        cancelbtn.setTitleColor(.white, for: .normal)
        cancelbtn.titleLabel?.font = .large
        cancelbtn.layer.cornerRadius = 4
        cancelbtn.backgroundColor = .red
        
        sureBtn.setTitleColor(.white, for: .normal)
        sureBtn.titleLabel?.font = .large
        sureBtn.layer.cornerRadius = 4
        sureBtn.backgroundColor = .red
        
        inputFile.layer.cornerRadius = 4
        inputFile.layer.borderColor = UIColor.lightGray.cgColor
        inputFile.layer.borderWidth = 0.5
        inputFile.clearButtonMode = .always
        inputFile.delegate = self
        inputFile.placeholder = "Please enter a new name".localize()
        inputFile.returnKeyType = .done
        
        textView.layer.cornerRadius = 4
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.borderWidth = 1
        textView.delegate = self
        textView.returnKeyType = .done
    }

    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        inputFile.resignFirstResponder()
        textView.resignFirstResponder()
        return true
    }
    
    func textViewDidChangeSelection(_ textView: UITextView) {
        countLabel.text = "(\(textView.text.count)/\(140))"
    }
    @IBAction func onSureAction(_ sender: Any) {
        if !inputFile.isHidden,
           let text = inputFile.text,
           text.count > 0 {
            if let actionHandler = actionHandler {
                actionHandler(text)
            }
            return
        }
        if  !textView.isHidden,
                textView.text.count > 0 {
            if let actionHandler = actionHandler {
                actionHandler(textView.text)
            }
            return
        }
        CDHUDManager.shared.showText("Please enter content".localize())
    }
    
    @IBAction func onCancelAction(_ sender: Any) {
        if let actionHandler = actionHandler {
            actionHandler(nil)
        }
    }
}
