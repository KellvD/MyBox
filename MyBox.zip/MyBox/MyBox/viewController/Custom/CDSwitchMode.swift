//
//  CDSwitchMode.swift
//  MyBox
//
//  Created by Kellv on 2024/11/18.
//  Copyright © 2024 Kellv. 2012-2019. All rights reserved.
//

import UIKit


struct CDSwitchMode {
    enum ModeType: String {
        case name = "Name"
        case createTime = "Create Time"
        case modifyTime = "Modify Time"
        case fileCount = "Files Count"
        case size = "Size"
        case fake = "Visitor mode"
        case Format = "Format"
        case importTime = "Import Time"
        case length = "Length"
        case during = "During"
        case location = "Location"
        case mark = "Remark"
    }

    var type: ModeType
    var isSwiHidden:Bool = true
    var value:String?
    var isCanEdit:Bool = false
   
    init(type: ModeType, 
         isSwiHidden: Bool = true,
         value: String? = nil,
         isCanEdit: Bool = false) {
        self.type = type
        self.isSwiHidden = isSwiHidden
        self.value = value
        self.isCanEdit = isCanEdit
    }
}
