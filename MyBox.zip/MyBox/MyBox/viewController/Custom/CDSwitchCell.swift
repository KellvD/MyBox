//
//  CDSwitchCell.swift
//  MyBox
//
//  Created by changdong on 2020/11/12.
//  Copyright © 2020 changdong. All rights reserved.
//

import UIKit
import SnapKit
class CDSwitchCell: UITableViewCell {

    public var swi: UISwitch!
    public var titleLabel: UILabel!
    public var valueLabel: UILabel!
    private var separatorLine: UIView!
    private var swiBlock:((CDSwitchMode,UISwitch) -> Void)!
    private var mode:CDSwitchMode!
    public var avatarView: UIImageView!
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .default, reuseIdentifier: reuseIdentifier)

        let view = UIView()
        self.selectedBackgroundView = view
        self.selectedBackgroundView?.backgroundColor = .cellSelectColor

        titleLabel = UILabel()
        titleLabel.textColor = .textBlack
        titleLabel.font = .mid
        titleLabel.textAlignment = .left
        self.contentView.addSubview(titleLabel)
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(32)
            make.centerY.equalToSuperview()
        }
        
        avatarView = UIImageView()
        self.contentView.addSubview(avatarView)
        avatarView.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-16)
            make.width.height.equalTo(56)
        }
        avatarView.layer.cornerRadius = 8
        avatarView.layer.borderWidth = 1
        avatarView.layer.borderColor = UIColor.lightGray.cgColor
        avatarView.isHidden = true
        
        swi = UISwitch()
        swi.addTarget(self, action: #selector(onSwitchClick(swi:)), for: .valueChanged)
        self.contentView.addSubview(swi)
        swi.isHidden = true
        swi.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-32.0)
            make.width.equalTo(50.0)
            make.height.equalTo(30.0)
        }

        valueLabel = UILabel()
        valueLabel.font = .mid
        valueLabel.textColor = .textLightBlack
        valueLabel.textAlignment = .right
        valueLabel.lineBreakMode = .byTruncatingMiddle
        valueLabel.numberOfLines = 0
        self.contentView.addSubview(valueLabel)
        valueLabel.isHidden = true
        valueLabel.snp.makeConstraints { (make) in
            make.left.greaterThanOrEqualTo(titleLabel.snp.right).offset(15.0)
            make.centerY.equalTo(titleLabel)
            make.right.equalToSuperview().offset(-16.0)
        }

        separatorLine = UIView()
        separatorLine.backgroundColor = .separatorColor
        self.addSubview(separatorLine)
        separatorLine.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview()
            make.height.equalTo(1)
            make.left.equalToSuperview().offset(32.0)
            make.right.equalToSuperview().offset(-32.0)
        }
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }


    func loadMode(mode: CDSwitchMode, swiBlock :@escaping ((CDSwitchMode,UISwitch) -> Void)) {
        titleLabel.text = mode.type.rawValue
        valueLabel.text = mode.value
        valueLabel.isHidden = mode.value == nil
        swi.isHidden = mode.isSwiHidden
        accessoryType = mode.isCanEdit ? .disclosureIndicator:  .none 
        selectionStyle = mode.isCanEdit ? .default: .none
        self.swiBlock = swiBlock
        self.mode = mode
//        if mode.type == .fake {
//            swi.isOn = CDSignalTon.shared.fakeSwitch
//        }
        
        titleLabel.snp.removeConstraints()
        valueLabel.snp.removeConstraints()
        if mode.type == .mark {


            titleLabel.snp.makeConstraints { (make) in
                make.left.equalToSuperview().offset(32)
                make.top.equalToSuperview().offset(20)
            }
            valueLabel.snp.makeConstraints { (make) in
                make.left.greaterThanOrEqualTo(titleLabel.snp.right).offset(15.0)
                make.centerY.equalTo(titleLabel)
                make.right.equalToSuperview().offset(-32.0)
            }
        }else {
            titleLabel.snp.makeConstraints { (make) in
                make.left.equalToSuperview().offset(32)
                make.centerY.equalToSuperview()
            }
            valueLabel.snp.makeConstraints { (make) in
                make.left.greaterThanOrEqualTo(titleLabel.snp.right).offset(15.0)
                make.centerY.equalTo(titleLabel)
                make.right.equalToSuperview().offset(-32.0)
            }
        }
        
    }
    @objc private func onSwitchClick(swi: UISwitch) {
        guard let swiBlock = swiBlock else {
            return
        }
        swiBlock(self.mode,swi)
    }

    public func valueLabelIsAtBottom() {
        valueLabel.isHidden = false
        valueLabel.snp.removeConstraints()
        valueLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15.0)
            make.top.equalTo(titleLabel.snp.bottom)
        }
        valueLabel.font = .small
        valueLabel.textAlignment = .left
    }

    // 分割线是否隐藏
    var separatorLineIsHidden: Bool {
        set {
            separatorLine.isHidden = newValue
        }
        get {
            return false
        }
    }
}
