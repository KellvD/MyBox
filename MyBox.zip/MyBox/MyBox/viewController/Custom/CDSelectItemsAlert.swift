//
//  CDSelectItemsAlert.swift
//  MyBox
//
//  Created by Kellv on 2024/12/9.
//  Copyright © 2024 Kellvv   . All rights reserved.
//

import UIKit

class CDSelectItemsAlert: UIView {
    var dataArr:[String]! {
        didSet {
            popView.dataArr = dataArr
        }
    }
    private var popView: CDSelectItemsNib!
    var contentBlock:((String)->Void)?
    override init(frame: CGRect = CGRect(x: 0, y: 0, width: CDSCREEN_WIDTH, height: CDSCREEN_HEIGTH)) {
        super.init(frame: frame)
        addBlurView()
        let tap = UITapGestureRecognizer(target: self, action: #selector(dismiss))
        self.addGestureRecognizer(tap)
        
        let xib = UINib(nibName: "CDSelectItemsNib", bundle: nil)
        popView = xib.instantiate(withOwner: self, options: nil).first as? CDSelectItemsNib
        popView.layer.cornerRadius = 8
        popView.contentBlock = {[weak self] content in
            guard let self = self else{
                return
            }
            if let content = content,
               let contentBlock = contentBlock {
                contentBlock(content)
            }
            dismiss()
        }
        self.addSubview(popView)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func show() {
        let pickerH = CGFloat(dataArr.count * 48)
        popView.pickerHeightConstraint.constant = pickerH
        popView.frame = CGRect(x: 0, y: CDSCREEN_HEIGTH - pickerH - 88, width: CDSCREEN_WIDTH, height: pickerH + 88)
        UIView.animate(withDuration: 0.25) {
            self.minY = 0
        }
    }
    
    @objc func dismiss() {
        UIView.animate(withDuration: 0.25) {
            self.minY = CDSCREEN_HEIGTH
        }
    }
}

class CDSelectItemsNib: UIView {
    
    @IBOutlet weak var pickerHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var sureBtn: UIButton!
    var dataArr:[String] = []
    var contentBlock:((String?)->Void)?
    var selectOption:String = ""
    override func awakeFromNib() {
        super.awakeFromNib()
        
        cancelBtn.setTitleColor(.white, for: .normal)
        cancelBtn.titleLabel?.font = .large
        cancelBtn.layer.cornerRadius = 4
        cancelBtn.backgroundColor = .red
        cancelBtn.setTitle("Cancel".localize(), for: .normal)
        
        sureBtn.setTitleColor(.white, for: .normal)
        sureBtn.titleLabel?.font = .large
        sureBtn.layer.cornerRadius = 4
        sureBtn.backgroundColor = .red
        sureBtn.setTitle("Sure".localize(), for: .normal)

        pickerView.delegate = self
        pickerView.dataSource = self
    }
    
    @IBAction func onSureAction(_ sender: Any) {
        if let actionHandler = contentBlock {
            actionHandler(selectOption)
        }
    }
    
    @IBAction func onCancelAction(_ sender: Any) {
        if let actionHandler = contentBlock {
            actionHandler(nil)
        }
    }
    
}
extension CDSelectItemsNib: UIPickerViewDelegate,UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        dataArr.count
    }
    
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        frame.width
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        48
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return dataArr[component]
    }
    
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectOption = dataArr[component]
    }
    
    
    
    
}
