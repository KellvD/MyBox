//
//  CDSwitchTableView.swift
//  MyBox
//
//  Created by Kellv on 2024/11/18.
//  Copyright © 2024 Kellv. 2012-2019. All rights reserved.
//

import UIKit

class CDSwitchTableView: UITableView,UITableViewDelegate,UITableViewDataSource {
    
    private var modes: [[CDSwitchMode]] = []
    private var didSelectHandler:((CDSwitchMode,UISwitch?) -> Void)!

    init(frame: CGRect, modes: [[CDSwitchMode]],didSelectHandler:@escaping ((CDSwitchMode,UISwitch?) -> Void)) {
        super.init(frame: frame, style: .grouped)
        self.delegate = self
        self.dataSource = self
        self.separatorStyle = .none
        self.register(CDSwitchCell.self, forCellReuseIdentifier: "MineSwitchCell")
        self.modes = modes
        self.didSelectHandler = didSelectHandler
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return modes.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        modes[section].count
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let mode = modes[indexPath.section][indexPath.row]
        if mode.type == .mark {
            return 148.0
        }
        return CELL_HEIGHT
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return SECTION_SPACE
    }

    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.01
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }

    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "MineSwitchCell") as? CDSwitchCell {
            let mode = modes[indexPath.section][indexPath.row]
            cell.loadMode(mode: mode, swiBlock: didSelectHandler)
            cell.separatorLineIsHidden = indexPath.row == modes[indexPath.section].count - 1
            return cell
        }
        return UITableViewCell()
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let mode = modes[indexPath.section][indexPath.row]

        if mode.isCanEdit {
            didSelectHandler(mode,nil)
        }
    }

    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        let normalLayer = CAShapeLayer()
        let selectLayer = CAShapeLayer()

        let radius = 8.0
        cell.backgroundColor = .clear
        let bounds = cell.bounds.insetBy(dx:12.0, dy:0)
        let rowNum = tableView.numberOfRows(inSection: indexPath.section)
        var bezierPath:UIBezierPath
        if(rowNum==1) {
            bezierPath = UIBezierPath(roundedRect: bounds, byRoundingCorners: .allCorners, cornerRadii:CGSize(width: radius, height: radius))
        }else{
            if(indexPath.row==0) {
                bezierPath = UIBezierPath(roundedRect: bounds, byRoundingCorners:[UIRectCorner.topLeft,UIRectCorner.topRight], cornerRadii:CGSize(width: radius, height: radius))
            }else if(indexPath.row==rowNum-1) {
                bezierPath = UIBezierPath(roundedRect: bounds, byRoundingCorners: [UIRectCorner.bottomLeft,UIRectCorner.bottomRight], cornerRadii:CGSize(width: radius, height: radius))
            }else{
                bezierPath = UIBezierPath(rect: bounds)
            }
        }

        normalLayer.path = bezierPath.cgPath
        selectLayer.path = bezierPath.cgPath

        normalLayer.borderColor = UIColor.red.cgColor
        normalLayer.borderWidth = 1
        
        let nomarBgView = UIView(frame: bounds)
        normalLayer.fillColor = UIColor(255, 255, 255).cgColor
        nomarBgView.layer.insertSublayer(normalLayer, at:0)
        nomarBgView.backgroundColor = .clear
        cell.backgroundView = nomarBgView
    
        let selectBgView = UIView(frame: bounds)
        selectLayer.fillColor = UIColor(236, 240, 244).cgColor
        selectBgView.layer.insertSublayer(selectLayer, at:0)
        cell.selectedBackgroundView = selectBgView
    }
}
