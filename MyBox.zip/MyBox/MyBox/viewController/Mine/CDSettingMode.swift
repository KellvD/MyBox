//
//  CDSettingMode.swift
//  MyBox
//
//  Created by Kellv on 2024/7/13.
//  Copyright © 2024 Kellv. 2012-2019. All rights reserved.
//

import UIKit
typealias SwitchBlock = (_ swi: UISwitch, _ option: CDOptions) -> Void

struct CDSettingMode{
    enum CDAccessoryType {
        case none
        case disclosureIndicator
        case swi
    }
    var name: CDOptions
    var value: String?
    var accessoryType: CDAccessoryType? = CDSettingMode.CDAccessoryType.none
    var swiBlock: SwitchBlock?
    var height: CGFloat? = CELL_HEIGHT
    init(name: CDOptions, value: String? = nil, accessoryType: CDAccessoryType? = CDSettingMode.CDAccessoryType.none, swiBlock: SwitchBlock? = nil, height: CGFloat? = CELL_HEIGHT) {
        self.name = name
        self.value = value
        self.accessoryType = accessoryType
        self.swiBlock = swiBlock
        self.height = height
    }
    
    static var commonData: [[CDSettingMode]] {
        var options: [CDSettingMode] = []
        let commonOptions:[CDOptions] = [.commonTheme,.commonAppIcon,.commonTransition]
        for option in commonOptions {
            let set = CDSettingMode(name: option)
            options.append(set)
        }
        return [options]
    }
}

enum CDOptions: String {
    case about = "设备详情"
    case storage = "文件存储"
    case privacy = "隐私"
    case waterMark = "水印模式"
    case log = "日志"
    case rate = "评论"
    case ChangePwd = "修改密码"
    case TouchID = "Touch ID"
    case FakeSet = "访客模式"
    case LogSet  = "日志设置"
    case LogPreview = "日志预览"
    
    // 文件详情
    case name = "名称"
    case format = "格式"
    case createTime = "创建时间"
    case importTime = "导入时间"
    case modifyTime = "修改时间"
    case frame = "尺寸"
    case size = "大小"
    case mark = "备注"
    case location = "创建定位"
    case durtion = "时长"
    case count = "文件数量"
    case fake = "访客不可见"
   
    case userAvatar = "Avatar"
    case userName = "Name"
    case userType = "User Type"
    case userValidityTime = "Expiration Date"
    case userPwd = "Change Password"
    
    case commonTheme = "Customized App Theme"
    case commonAppIcon = "Customize App Icon"
    case commonTransition = "Customized App Transition"
}

