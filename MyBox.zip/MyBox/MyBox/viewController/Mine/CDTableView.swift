//
//  CDTableView.swift
//  MyBox
//
//  Created by Kellv on 2024/7/13.
//  Copyright © 2024 Kellv. 2012-2019. All rights reserved.
//

import UIKit

class CDTableView: UITableView,UITableViewDelegate,UITableViewDataSource {

    var didSelectedHandler:((CDSettingMode)->Void)?
    var dataArr:[[CDSettingMode]] = []
    override init(frame: CGRect, style: UITableView.Style) {
        super.init(frame: frame, style: style)
        self.separatorStyle = .none
        self.delegate = self
        self.dataSource = self
        self.sectionHeaderHeight = SECTION_SPACE
        self.sectionFooterHeight = 0.01
        self.tableHeaderView = nil
        self.tableFooterView = nil
        self.register(CDSwitchCell.self, forCellReuseIdentifier: "MineSwitchCell")

    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return dataArr.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataArr[section].count
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let mode = dataArr[indexPath.section][indexPath.row]

        return mode.height!
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

         let cellId = "MineSwitchCell"
        let cell: CDSwitchCell! = tableView.dequeueReusableCell(withIdentifier: cellId) as? CDSwitchCell
        
        let mode = dataArr[indexPath.section][indexPath.row]
        cell.titleLabel.text = mode.name.rawValue.localize()
        cell.swi.isHidden = mode.accessoryType != .swi
        cell.accessoryType = mode.accessoryType != .swi ? .disclosureIndicator : .none
        cell.selectionStyle =  mode.accessoryType != .swi ? .default : .none
        if let value = mode.value {
            cell.valueLabel.isHidden = false
            cell.valueLabel.text = value
        }
        
        if mode.accessoryType == .swi {
            cell.swi.isOn = CDSignalTon.shared.waterBean.isOn
//            cell.swiBlock = mode.swiBlock
        }
        // 最后一个没有分割线
        cell.separatorLineIsHidden = (indexPath.row == dataArr[indexPath.section].count - 1) || dataArr[indexPath.section].count == 1
        return cell
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.redraw(tableView: tableView, indexPath: indexPath)
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let option = dataArr[indexPath.section][indexPath.row]
        guard let didSelectedHandler = didSelectedHandler else {
            return
        }
        
        didSelectedHandler(option)
    }
}
