//
//  CDPrivacyViewController.swift
//  MyBox
//
//  Created by changdong on 2020/11/12.
//  Copyright © 2020 changdong. All rights reserved.
//

import UIKit
import LocalAuthentication


class CDOptionViewController: CDBaseAllViewController {
    
    private var tableview: CDTableView!
    var options: [[CDOptions]] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview = CDTableView(frame: CGRect(x: 0, y: 0, width: CDSCREEN_WIDTH, height: CDSCREEN_HEIGTH), style: .grouped)
        tableview.didSelectedHandler = {[weak self] mode in
            guard let self = self else {
                return
            }
            self.didSelectedHandler(mode: mode)
            
        }
        self.view.addSubview(tableview)
        initData()
    }

    func initData() {
        var dataArr: [[CDSettingMode]] = []
        for sections in options {
            var tmps: [CDSettingMode] = []
            for row in sections {
                switch row {
                case .LogSet,.TouchID,.FakeSet:
                    let mode = CDSettingMode(name: row, accessoryType: .swi, swiBlock: onSwitchClick)
                    tmps.append(mode)
                default:
                    let mode = CDSettingMode(name: row, accessoryType: .disclosureIndicator, swiBlock: nil)
                    tmps.append(mode)
                }
            }
            dataArr.append(tmps)
        }
        tableview.dataArr = dataArr
        tableview.reloadData()
    }


    func didSelectedHandler(mode: CDSettingMode) {
        //        switch mode.name {
        //        case.ChangePwd:
        //            let setPwdVC = CDSetPwdViewController()
        //            setPwdVC.isFake = false
        //            setPwdVC.isModify = !CDSignalTon.shared.basePwd.isEmpty
        //            setPwdVC.title = CDSignalTon.shared.basePwd.isEmpty ? "设置密码".localize() : "修改密码".localize()
        //            self.navigationController?.pushViewController(setPwdVC, animated: true)
        //        case.FakeSet:
        //            if CDSignalTon.shared.fakeSwitch {
        //                let fakePwd = JYContainer.shared.queryUserFakeKeyWithUserId(userId: CDUserId())
        //                let setPwdVC = CDSetPwdViewController()
        //                setPwdVC.isFake = true
        //                setPwdVC.isModify = !fakePwd.isEmpty
        //                setPwdVC.title = fakePwd.isEmpty ? "设置访客密码".localize() : "修改访客密码".localize()
        //                self.navigationController?.pushViewController(setPwdVC, animated: true)
        //                
        //            }
        //        case.LogSet, .LogPreview:
        //            if CDLogBean.isOn {
        //                let logVC = CDLogViewController()
        //                logVC.isSet = mode.name == .LogSet
        //                self.navigationController?.pushViewController(logVC, animated: true)
        //                
        //            }
        //        default:
        //            break
        
    }
    // 响应
    private func onTouchIDSwitchClick(swi: UISwitch) {
        
        //        if swi.isOn {
        //            showTouchId { (success, _) in
        //                if success {
        //                    CDConfigFile.setBoolValueToConfigWith(key: .touchIdSwi, boolValue: true)
        //                    CDSignalTon.shared.touchIDSwitch = true
        //                    CDPrintManager.log("指纹密码打开", type: .InfoLog)
        //                } else {
        //                    DispatchQueue.main.async {
        //                        CDHUDManager.shared.showText("您的设备没有开启指纹或者您的设备不支持指纹功能".localize())
        //                        CDSignalTon.shared.touchIDSwitch = false
        //                    }
        //
        //                }
        //            }
        //
        //        } else {
        //            CDConfigFile.setBoolValueToConfigWith(key: .touchIdSwi, boolValue: false)
        //            CDSignalTon.shared.touchIDSwitch = false
        //            CDPrintManager.log("指纹密码关闭", type: .InfoLog)
        //        }
        
    }
    
    private func onFakeSwitchClick(swi: UISwitch) {
        
        //        if swi.isOn {
        //            CDConfigFile.setBoolValueToConfigWith(key: .fakeSwi, boolValue: true)
        //            CDSignalTon.shared.fakeSwitch = true
        //            CDPrintManager.log("访客模式打开", type: .InfoLog)
        //        } else {
        //
        //            let alert = UIAlertController(title: nil, message: "关闭访客模式".localize(), preferredStyle: .alert)
        //            alert.addAction(UIAlertAction(title: "取消".localize(), style: .cancel, handler: { (_: UIAlertAction) in
        //               swi.isOn = true
        //            }))
        //            alert.addAction(UIAlertAction(title: "确定".localize(), style: .default, handler: { (_: UIAlertAction) in
        //                JYContainer.shared.updateUserFakePwdWith(pwd: "")
        //                CDSignalTon.shared.fakeSwitch = false
        //                CDConfigFile.setBoolValueToConfigWith(key: .fakeSwi, boolValue: false)
        //                CDPrintManager.log("访客模式关闭", type: .InfoLog)
        //            }))
        //            self.present(alert, animated: true, completion: nil)
        //        }
    }
    
    func showTouchId(block:@escaping(Bool, Error?) -> Void) {
        let lol = LAContext()
        var error: NSError?
        if lol.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
            lol.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: "解锁".localize()) { (success, error) in
                block(success, error)
            }
        } else {
            block(false, error)
        }
    }
    
    private func onLogSwiSwitchClick(swi: UISwitch) {
        
        //        if swi.isOn {
        //            let logVC = CDLogViewController()
        //            logVC.isSet = true
        //            self.navigationController?.pushViewController(logVC, animated: true)
        //        } else {
        //
        //            let alert = UIAlertController(title: nil, message: "确定关闭日志？", preferredStyle: .alert)
        //            alert.addAction(UIAlertAction(title: "取消".localize(), style: .cancel, handler: { (_: UIAlertAction) in
        //                swi.isOn = true
        //            }))
        //            alert.addAction(UIAlertAction(title: "确定".localize(), style: .default, handler: { (_: UIAlertAction) in
        //                CDLogBean.closeLogConfig()
        ////                self.tableView.reloadRows(at: [IndexPath(item: 0, section: 0)], with: .none)
        //            }))
        //            self.present(alert, animated: true, completion: nil)
        //        }
    }
    
    func onSwitchClick(swi: UISwitch, option: CDOptions) {
        //        self.onLogSwiSwitchClick(swi: swi)
    }
    
}
