//
//  CDMineViewController.swift
//  MyRule
//
//  Created by changdong on 2018/12/3.
//  Copyright © 2018 changdong. All rights reserved.
//

import UIKit
import StoreKit
class CDMineViewController: CDBaseAllViewController {
    private var tableview: CDTableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.hiddBackbutton()
        tableview = CDTableView(frame: CGRect(x: 0, y: 0, width: CDSCREEN_WIDTH, height: CDSCREEN_HEIGTH), style: .grouped)
        tableview.didSelectedHandler = {[weak self] mode in
            guard let self = self else {
                return
            }
            self.didSelectedHandler(mode: mode)
            
        }
        self.view.addSubview(tableview)
        initData()
    }
    
    func initData() {
        let options: [[CDOptions]] = [[.about],[.storage],[.privacy],[.waterMark],[.log],[.rate]]
        var dataArr: [[CDSettingMode]] = []
        for option in options {
            var tmps: [CDSettingMode] = []
            for opt in option {
                if opt == .waterMark {
//                    let mode = CDSettingMode(name: opt, accessoryType: .swi, swiBlock: onWaterSwitchClick)
//                    tmps.append(mode)
                }else {
                    let mode = CDSettingMode(name: opt, accessoryType: .disclosureIndicator, swiBlock: nil)
                    tmps.append(mode)
                }
            }
            dataArr.append(tmps)
        }
        tableview.dataArr = dataArr
        tableview.reloadData()
    }

    
    func didSelectedHandler(mode: CDSettingMode) {
        switch mode.name {
        case .about:
            let device = CDDeviceInfoViewController()
            device.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(device, animated: true)

        case .storage:
            let mem  = CDMemoryViewController()
            mem.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(mem, animated: true)
        case .privacy,.log:
            let privacy = CDOptionViewController()
            privacy.hidesBottomBarWhenPushed = true
            privacy.title = mode.name.rawValue.localize()
            privacy.options = mode.name == .log ? [[.LogSet, .LogPreview]]:[[.ChangePwd, .TouchID, .FakeSet]]
            self.push(to: privacy)

        case .waterMark:
            if CDSignalTon.shared.waterBean.isOn {
                self.pushSetWatermaek()
            }
        case .rate:
            rateUs(isPopAppStroe: false)
        default:
            break
        }

    }

    private func pushSetWatermaek() {
        let water = CDMarkFileViewController()
        water.hidesBottomBarWhenPushed = true
        water.title = "水印模式".localize()
        water.maxTextCount = CDMaxWatermarkLength
        water.oldContent = CDSignalTon.shared.waterBean.text
        water.markType = .waterInfo
        water.markHandle = {(newContent) in
            CDWaterBean.setWaterConfig(isOn: true, text: newContent!)
            CDSignalTon.shared.waterBean = CDWaterBean()
            let myDelegate = UIApplication.shared.delegate as! CDAppDelegate
            CDSignalTon.shared.addWartMarkToWindow(appWindow: myDelegate.window!)
            CDPrintManager.log("水印内容设置:\(newContent!)", type: .InfoLog)
        }
        self.navigationController?.pushViewController(water, animated: true)
    }

    private func onWaterSwitchClick(swi: UISwitch){
        if swi.isOn {
            self.pushSetWatermaek()
        } else {
//
//            self.alert(message:"确定关闭水印？".localize() , style: .alert, cancelTitle: "取消".localize(),cancelHandler: {
//                swi.isOn = true
//
//            }, defaultTitleL: "确定".localize()) {
//                let myDelegate = UIApplication.shared.delegate as! CDAppDelegate
//                CDSignalTon.shared.removeWaterMarkFromWindow(window: myDelegate.window!)
//                CDWaterBean.setWaterConfig(isOn: false, text: GetAppName())
//                CDSignalTon.shared.waterBean = CDWaterBean()
//               
//                CDPrintManager.log("水印开关关闭", type: .InfoLog)
//            }
        }
    }

    func rateUs(isPopAppStroe: Bool) {
        if isPopAppStroe {
            if UIApplication.shared.canOpenURL(URL(string: appStoreRateUrl)!) {
                    UIApplication.shared.open(URL(string: appStoreRateUrl)!, options: [:], completionHandler: nil)
                }
        } else {
            guard let scene = UIDevice.keyWindow().windowScene else {
                return
            }
            if #available(iOS 14.0, *){
                SKStoreReviewController.requestReview(in: scene)
            }
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}


