//
//  CDFaceLockViewController.swift
//  MyRule
//
//  Created by changdong on 2019/4/4.
//  Copyright © 2019 changdong. All rights reserved.
//

import UIKit
import AVFoundation
class CDFaceLockViewController: CDBaseAllViewController, AVCaptureMetadataOutputObjectsDelegate {

//    var device = <#value#>
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//
//        //获取输入设备
//        guard let device = AVCaptureDevice.default(for: .video) else {
//            return
//        }
//        //创建输入对象
//        guard let device_in = try? AVCaptureDeviceInput(device: device) else {
//            return
//        }
//
//        //获取原数据的数处对象
//        let originDataOutput = AVCaptureMetadataOutput()
//        originDataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
//
//        //输出对象，输出的数据是人脸
//        originDataOutput.metadataObjectTypes = [.face]
//
//    }

}
