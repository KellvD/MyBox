//
//  CDMarqueeView.swift
//  MyBox
//
//  Created by changdong on 2021/10/9.
//  Copyright © 2018 changdong. All rights reserved.
//

import UIKit

class CDMarqueeView: UIView {

        func start() {

        }

        func stop() {

        }

}
