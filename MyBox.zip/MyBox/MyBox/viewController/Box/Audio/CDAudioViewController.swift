//
//  CDAudioViewController.swift
//  MyRule
//
//  Created by changdong on 2018/12/5.
//  Copyright © 2018 changdong. All rights reserved.
//

import UIKit
class CDAudioViewController: CDBaseAllViewController, UITableViewDelegate, UITableViewDataSource {

    public var folderInfo: JYFolderInfo!
    private var tableblew: UITableView!
    private var toolbar: CDToolBar!
    private var batchBtn = UIButton(type: .custom)
    private var backBtn = UIButton(type: .custom)
    private var fileArr: [JYFileInfo] = []
    private var curPlayCellPath: IndexPath?
    private var selectCount: Int = 0
    private var selectedAudioArr: [JYFileInfo] = []
    private var isNeedReloadData: Bool = false // 是否刷新数据
    deinit {
        super.removeObserver(self, forKeyPath: "fileArr")
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableblew.setEditing(false, animated: false)
        // push,present前设置pop，dismiss后本界面是否刷新数据。原则上离开本界面后对数据有操作的都需要刷新
        if isNeedReloadData {
            isNeedReloadData = false
            refreshData()
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "语音文件"
        isNeedReloadData = true
        self.toolbar = CDToolBar(frame: CGRect(x: 0, y: CDViewHeight - BottomBarHeight, width: CDSCREEN_WIDTH, height: BottomBarHeight), barType: .AudioTools, superVC: self)

        view.addSubview(self.toolbar)

        tableblew = UITableView(frame: CGRect(x: 0, y: 0, width: CDSCREEN_WIDTH, height: toolbar.minY), style: .plain)
        tableblew.delegate = self
        tableblew.dataSource = self
        tableblew.separatorStyle = .none
        view.addSubview(tableblew)
        tableblew.register(CDFileTableViewCell.self, forCellReuseIdentifier: "audioCellId")

        batchBtn.setImage(UIImage(named: "edit"), for: .normal)
        batchBtn.addTarget(self, action: #selector(batchBtnClick), for: .touchUpInside)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: batchBtn)

        backBtn = UIButton(type: .custom)
        backBtn.setTitle("返回".localize(), for: .normal)
        backBtn.addTarget(self, action: #selector(backBtnClick), for: .touchUpInside)
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: backBtn)

    }

    private func refreshData() {
        toolbar.enableReloadBar(isEnable: false)
        fileArr = JYContainer.shared.queryAllFile(folderId: folderInfo.folderId)
        tableblew.reloadData()
    }

    private func handelSelectedArr() {
        selectedAudioArr.removeAll()
        fileArr.forEach { (tmpFile) in
            if tmpFile.isSelected {
                selectedAudioArr.append(tmpFile)
            }
        }
    }
    // 批量操作
    @objc func batchBtnClick() {
        banchHandleFiles(isSelected: !batchBtn.isSelected)
    }

    private func banchHandleFiles(isSelected: Bool) {
//        playView.stopPlayer()
        selectCount = 0
        batchBtn.isSelected = isSelected
        if batchBtn.isSelected { // 点了选择操作
            self.backBtn.setTitle("全选".localize(), for: .normal)
            batchBtn.setImage(UIImage(named: "no_edit"), for: .normal)
            toolbar.hiddenReloadBar(isMulit: true)
            fileArr.forEach { (file) in
                file.isSelected = false
            }
        } else {
            // 1.全选变返回
            self.backBtn.setTitle("返回".localize(), for: .normal)
            batchBtn.setImage(UIImage(named: "edit"), for: .normal)
            toolbar.hiddenReloadBar(isMulit: false)
            fileArr.forEach { (tmpFile) in
                tmpFile.isSelected = false
            }
        }
        tableblew.reloadData()
    }

    // 返回
    @objc func backBtnClick() {
        if batchBtn.isSelected { //
            if self.backBtn.currentTitle == "全选".localize() { // 全选
                fileArr.forEach { (tmpFile) in
                    tmpFile.isSelected = true
                }
                selectCount = fileArr.count
            } else {
                fileArr.forEach { (tmpFile) in
                    tmpFile.isSelected = false
                }
                selectCount = 0
            }
            refreshUI()

        } else {
            self.navigationController?.popViewController(animated: true)
        }

    }

    func refreshUI() {
        toolbar.enableReloadBar(isEnable: selectCount > 0)
        toolbar.appendItem.isEnabled = selectCount >= 2
        if selectCount == fileArr.count && fileArr.count > 0 {
            self.backBtn.setTitle("全不选".localize(), for: .normal)
            backBtn.frame = CGRect(x: 0, y: 0, width: 80, height: 44)
            backBtn.contentHorizontalAlignment = .left
        } else {
            backBtn.setTitle("全选".localize(), for: .normal)
        }
        tableblew.reloadData()
    }

    // MARK: 导入
    @objc func documentItemClick() {
        isNeedReloadData = true
        let documentTypes = ["public.audio"]
        super.subFolderId = folderInfo.folderId
        super.subFolderType = folderInfo.folderType
        super.docuemntPickerComplete = {[unowned self](_ success: Bool) -> Void in
            if success {
                self.refreshData()
            }
        }
        presentDocumentPicker(documentTypes: documentTypes)
    }

    // MARK: 录入
    @objc func importItemClick() {
        isNeedReloadData = true
        let recordVC = CDAudioRecordViewController()
        recordVC.folderId = folderInfo.folderId
        self.navigationController?.pushViewController(recordVC, animated: true)
    }

    // MARK: 分享事件
    @objc func shareBarItemClick() {
        handelSelectedArr()
        var shareArr: [NSObject] = []
        for index in 0..<self.selectedAudioArr.count {
            let file: JYFileInfo = self.selectedAudioArr[index]
            let videoPath = file.path!.absolutePath
            let url = videoPath.pathUrl
            shareArr.append(url as NSObject)
        }
        presentShareActivityWith(dataArr: shareArr) { (_) in
            self.banchHandleFiles(isSelected: false)
        }
    }

    // MARK: 删除
    @objc func deleteBarItemClick() {
        handelSelectedArr()
        let btnTitle = selectedAudioArr.count > 1 ? String(format: "删除%d条语音".localize(), selectedAudioArr.count):"删除语音".localize()
        let sheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        sheet.addAction(UIAlertAction(title: btnTitle, style: .destructive, handler: { (_) in
            CDHUDManager.shared.showWait("删除中...".localize())
            self.selectedAudioArr.forEach({ (tmpFile) in
                let defaultPath = tmpFile.path!.absolutePath
                defaultPath.delete()
                JYContainer.shared.deleteFile(fileId: tmpFile.fileId)
                let index = self.fileArr.firstIndex(of: tmpFile)
                self.fileArr.remove(at: index!)
            })
            DispatchQueue.main.async {
                CDHUDManager.shared.hideWait()
                CDHUDManager.shared.showComplete("删除完成".localize())
                self.banchHandleFiles(isSelected: false)
            }
        }))
        sheet.addAction(UIAlertAction(title: "取消".localize(), style: .cancel, handler: nil))
        self.present(sheet, animated: true, completion: nil)

    }

    // 拼接
    @objc func appendItemClick() {
        handelSelectedArr()
        let sheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        sheet.addAction(UIAlertAction(title: "合成选中的\(selectedAudioArr.count)条音频", style: .default, handler: {[unowned self] (_) in
            DispatchQueue.main.async {
                CDHUDManager.shared.showWait("正在处理中...".localize())
            }

            CDSignalTon.shared.appendAudio(folderId: self.folderInfo.folderId, appendFile: self.selectedAudioArr) {[unowned self] (success) in
                DispatchQueue.main.async {
                    CDHUDManager.shared.hideWait()
                    self.refreshData()
                    if success {
                        CDHUDManager.shared.showText("合成成功".localize())
                    } else {
                        CDHUDManager.shared.showText("合成失败".localize())
                    }
                }
            }
        }))
        sheet.addAction(UIAlertAction(title: "取消".localize(), style: .cancel, handler: nil))
        self.present(sheet, animated: true, completion: nil)
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 65
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fileArr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cellId = "audioCellId"
        let cell: CDFileTableViewCell! = tableView.dequeueReusableCell(withIdentifier: cellId, for: indexPath) as? CDFileTableViewCell
        
        if batchBtn.isSelected {
            let tmpFile = fileArr[indexPath.row]
            if tmpFile.isSelected {
                cell.showSelectIcon = .selected
            } else {
               cell.showSelectIcon = .show
            }
        } else {
            cell.showSelectIcon = .hide
        }
        let fileInfo: JYFileInfo = fileArr[indexPath.row]
        cell.setConfigFileData(fileInfo: fileInfo)

        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if batchBtn.isSelected {
            let tmpFile = fileArr[indexPath.row]
            if tmpFile.isSelected {
                selectCount -= 1
                tmpFile.isSelected = false
            } else {
                selectCount += 1
                tmpFile.isSelected = true
            }

            refreshUI()
        } else {
            curPlayCellPath = indexPath
            let fileInfo: JYFileInfo = fileArr[indexPath.row]
            tableblew.deselectRow(at: indexPath, animated: false)
            let audioPath = fileInfo.path!.absolutePath
            let playVC = CDAudioPlayViewController()
            playVC.audioPath = audioPath
            playVC.fileName = fileInfo.name
            playVC.timeLength = fileInfo.timeLength
            self.navigationController?.pushViewController(playVC, animated: true)

        }

    }

    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        if batchBtn.isSelected {
            let tmpFile = fileArr[indexPath.row]
            if tmpFile.isSelected {
                selectCount -= 1
                tmpFile.isSelected = false
            } else {
                selectCount += 1
                tmpFile.isSelected = true
            }
            refreshUI()
        }
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return !batchBtn.isSelected
    }

    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let tmpFile: JYFileInfo = fileArr[indexPath.row]
        let detail = UIContextualAction(style: .normal, title: nil) { (_, _, _) in
            let fileDVC = CDDetailViewController()
            fileDVC.file = tmpFile
            self.navigationController?.pushViewController(fileDVC, animated: true)
        }
        detail.backgroundColor = .baseBgColor
        detail.image = "files_more".image
        //
        let delete = UIContextualAction(style: .normal, title: "删除".localize()) { (_, _, _) in
            tmpFile.isSelected = true
            self.deleteBarItemClick()
        }
        delete.image = "删除红色".image
        let action = UISwipeActionsConfiguration(actions: [delete, detail])
        return action
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
