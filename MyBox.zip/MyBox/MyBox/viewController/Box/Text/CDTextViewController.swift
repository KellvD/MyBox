//
//  CDTextViewController.swift
//  MyRule
//
//  Created by changdong on 2018/12/28.
//  Copyright © 2018 changdong. All rights reserved.
//

import UIKit
import AVFoundation
import MJRefresh
import QuickLook
import QuickLookThumbnailing
import PDFKit

class CDTextViewController:
CDBaseAllViewController,
UITableViewDelegate,
UITableViewDataSource,
UIDocumentInteractionControllerDelegate,
CDDirNavBarDelegate,
QLPreviewControllerDelegate,
QLPreviewControllerDataSource {

    private var tablebview: UITableView!
    private var batchBtn = UIButton(type: .custom)
    private var backBtn = UIButton(type: .custom)
    private var toolbar: CDToolBar!
    private var dirNavBar: CDDirNavBar!
    private var textTD:(foldersArr: [JYFolderInfo], filesArr: [JYFileInfo])!
    private var selectFileCount: Int = 0
    private var selectFolderCount: Int = 0
    private var selectedFileArr: [JYFileInfo] = []
    private var selectedFolderArr: [JYFolderInfo] = []
    private var isNeedReloadData: Bool = false
    private var currentFolderId: Int!
    public var folderInfo: JYFolderInfo!

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if isNeedReloadData {
            isNeedReloadData = false
            refreshData(superId: folderInfo.folderId)
            CDSignalTon.shared.dirNavArr.removeAllObjects()// 进入文本文件
        }
        tablebview.setEditing(false, animated: false)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        isNeedReloadData = true
        currentFolderId = folderInfo.folderId

        dirNavBar = CDDirNavBar(frame: CGRect(x: 0, y: 0, width: CDSCREEN_WIDTH, height: 48))
        dirNavBar.dirDelegate = self
        view.addSubview(dirNavBar)
        self.toolbar = CDToolBar(frame: CGRect(x: 0, y: CDViewHeight - BottomBarHeight, width: CDSCREEN_WIDTH, height: BottomBarHeight), barType: .TextTools, superVC: self)
        self.view.addSubview(self.toolbar)

        tablebview = UITableView(frame: CGRect(x: 0, y: dirNavBar.maxY, width: CDSCREEN_WIDTH, height: self.toolbar.minY - dirNavBar.maxY), style: .plain)
        tablebview.delegate = self
        tablebview.dataSource = self
        tablebview.separatorStyle = .none
        self.view.addSubview(tablebview)
        tablebview.register(CDFileTableViewCell.self, forCellReuseIdentifier: "textCellId")


        batchBtn.setImage(UIImage(named: "edit"), for: .normal)
        batchBtn.addTarget(self, action: #selector(batchBtnClick), for: .touchUpInside)
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: batchBtn)

        self.backBtn.setTitle("返回".localize(), for: .normal)
        self.backBtn.addTarget(self, action: #selector(backBtnClick), for: .touchUpInside)
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(customView: self.backBtn)

        hiddenDirNavBar()

    }

    private func refreshData(superId: Int) {
        toolbar.enableReloadBar(isEnable: false)
//        textTD = JYContainer.shared.queryAllContentFromFolder(folderId: superId)
        tablebview.reloadData()
        self.noMoreDataView.isHidden = textTD.filesArr.count + textTD.foldersArr.count > 0
    }

    private func handelSelectedArr() {
        selectedFileArr.removeAll()
        selectedFolderArr.removeAll()

        selectedFileArr = textTD.filesArr.filter({ (tmp) -> Bool in
            tmp.isSelected
        })
        selectedFolderArr = textTD.foldersArr.filter({ (tmp) -> Bool in
            tmp.isSelected
        })
    }
    // 多选
    @objc private func batchBtnClick() {
        batchHandleFiles(isSelected: !batchBtn.isSelected)
    }

    private func batchHandleFiles(isSelected: Bool) {
        selectFileCount = 0
        selectFolderCount = 0
        batchBtn.isSelected = isSelected
        if batchBtn.isSelected { // 点了批量操作
            // 1.返回按钮变全选
            self.backBtn.setTitle("全选".localize(), for: .normal)
            batchBtn.setImage(UIImage(named: "no_edit"), for: .normal)
            // 所有文件，文件夹设置未选状态
            textTD.filesArr.forEach { (tmpFile) in
                tmpFile.isSelected = false
            }
            textTD.foldersArr.forEach { (tmpFolder) in
                tmpFolder.isSelected = false
            }
            toolbar.hiddenReloadBar(isMulit: true)
        } else {
            // 1.返回变全选
            self.backBtn.setTitle("返回".localize(), for: .normal)
            batchBtn.setImage(UIImage(named: "edit"), for: .normal)
            toolbar.hiddenReloadBar(isMulit: false)
            textTD.filesArr.forEach { (tmpFile) in
                tmpFile.isSelected = false
            }

            textTD.foldersArr.forEach { (tmpFile) in
                tmpFile.isSelected = false
            }
        }
        self.noMoreDataView.isHidden = textTD.filesArr.count + textTD.foldersArr.count > 0

        tablebview.reloadData()
    }

    // 返回
    @objc private func backBtnClick() {
        if batchBtn.isSelected {
            if self.backBtn.currentTitle == "全选".localize() { // 全选
                textTD.filesArr.forEach { (tmpFile) in
                     tmpFile.isSelected = true
                 }
                 textTD.foldersArr.forEach { (tmpFolder) in
                     tmpFolder.isSelected = true
                 }
                 selectFileCount = textTD.filesArr.count
                 selectFolderCount = textTD.foldersArr.count
            } else {
                textTD.filesArr.forEach { (tmpFile) in
                    tmpFile.isSelected = false
                }
                textTD.foldersArr.forEach { (tmpFolder) in
                    tmpFolder.isSelected = false
                }
                selectFileCount = 0
                selectFolderCount = 0
            }
            refreshUI()
        } else {
            self.navigationController?.popViewController(animated: true)
        }

    }

    private func refreshUI() {
        toolbar.enableReloadBar(isEnable: selectFileCount + selectFolderCount > 0)
        toolbar.moveItem.isEnabled = selectFileCount > 0 && selectFolderCount < 1
        toolbar.shareItem.isEnabled = selectFileCount > 0 && selectFolderCount < 1
        if selectFileCount == textTD.filesArr.count &&
            selectFolderCount == textTD.foldersArr.count &&
            (textTD.filesArr.count > 0 ||
            textTD.foldersArr.count > 0) {
            self.backBtn.setTitle("全不选".localize(), for: .normal)
            backBtn.frame = CGRect(x: 0, y: 0, width: 80, height: 44)
            backBtn.contentHorizontalAlignment = .left
        } else {
            backBtn.setTitle("全选".localize(), for: .normal)
        }
        tablebview.reloadData()
    }

    // 选择文件夹目录
   func onSelectedDirWithFolderId(folderId: Int) {
        tablebview.transition(subtype: .fromLeft, duration: 0.5)
        if folderId == folderInfo.folderId { // 根目录
            hiddenDirNavBar()
        }
        refreshData(superId: folderId)
    }

    private func hiddenDirNavBar() {
        UIView.animate(withDuration: 0.5, animations: {
            var frame = self.tablebview.frame
            if frame.origin.y > 0.0 {
                frame.origin.y = 0.0
                frame.size.height += 48.0
                self.tablebview.frame = frame
            }
        }) { (_) in
            self.dirNavBar.isHidden = true
            CDSignalTon.shared.dirNavArr.removeAllObjects()
        }
    }
    func showDirNavBar() {
        UIView.animate(withDuration: 0.25) {
            self.dirNavBar.isHidden = false
            var frame = self.tablebview.frame
            if frame.origin.y == CGFloat(0.0) {
                frame.origin.y = 48.0
                frame.size.height -= 48.0
                self.tablebview.frame = frame
            }
        }
    }
    // MARK: 分享事件
    @objc func shareBarItemClick() {
        handelSelectedArr()
        var shareArr: [NSObject] = []
        for index in 0..<self.selectedFileArr.count {
            let file: JYFileInfo = self.selectedFileArr[index]
            let filePath = file.path!.absolutePath
            let url = filePath.pathUrl
            shareArr.append(url as NSObject)
        }
        presentShareActivityWith(dataArr: shareArr) {[unowned self] (_) in
            self.batchHandleFiles(isSelected: false)
        }

    }
    // MARK: 移动
    @objc func moveBarItemClick() {
        isNeedReloadData = true
        handelSelectedArr()
        let folderList = CDPickerFolderViewController()
        folderList.selectedArr = selectedFileArr
        folderList.folderType = .TextFolder
        folderList.folderId = folderInfo.folderId
        self.navigationController?.pushViewController(folderList, animated: true)
    }

    // MARK: 删除
    @objc func deleteBarItemClick() {
        handelSelectedArr()
        let total = selectedFileArr.count + selectedFolderArr.count
        let btnTitle = total > 1 ? String(format: "删除%d个文件".localize(), selectedFileArr.count): "删除文件".localize()

        let sheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        sheet.addAction(UIAlertAction(title: btnTitle, style: .destructive, handler: { (_) in
            DispatchQueue.main.async {
                CDHUDManager.shared.showWait("删除中".localize())
            }

            DispatchQueue.global().async {
                self.selectedFileArr.forEach { (tmpFile) in
                    let filePath = tmpFile.path!.absolutePath
                    filePath.delete()
                    JYContainer.shared.deleteFile(fileId: tmpFile.fileId)

                    let index = self.textTD.filesArr.firstIndex(of: tmpFile)
                    self.textTD.filesArr.remove(at: index!)

                }
                self.selectedFolderArr.forEach { (tmpFolder) in
                    /*
                     文件夹中文件filePath：other/xxx/xxx/xxx，不能取最后部分拼接在other上
                     */
                    let folderPath = tmpFolder.path!.absolutePath
                    folderPath.delete()
                    let index = self.textTD.foldersArr.firstIndex(of: tmpFolder)
                    self.textTD.foldersArr.remove(at: index!)

                    // 删除数据库中数据，逐级删除文件
                    func deleteAllSubContent(subFolderId: Int) {
                        // 删除一级目录
                        JYContainer.shared.deleteFolder(folderId: subFolderId)
                        // 删除目录下子文件
                        JYContainer.shared.deleteFolder(superId: subFolderId)

                        let subAllFolders = JYContainer.shared.queryAllFolderId(superId: subFolderId)
                        for folderId in subAllFolders {
                            deleteAllSubContent(subFolderId: folderId)
                        }
                    }
                    deleteAllSubContent(subFolderId: tmpFolder.folderId)
                }
                DispatchQueue.main.async {
                    self.batchHandleFiles(isSelected: false)
                    CDHUDManager.shared.hideWait()
                    CDHUDManager.shared.showText("删除完成".localize())
                }
            }
        }))
        sheet.addAction(UIAlertAction(title: "取消".localize(), style: .cancel, handler: nil))
        present(sheet, animated: true, completion: nil)
    }

    // MARK: 
    @objc func documentItemClick() {
        // 查询地址：https://developer.apple.com/library/archive/documentation/Miscellaneous/Reference/UTIRef/Articles/System-DeclaredUniformTypeIdentifiers.html#//apple_ref/doc/uid/TP40009259
        let documentTypes = ["public.text", "com.adobe.pdf", "com.microsoft.word.doc", "com.microsoft.excel.xls", "com.microsoft.powerpoint.ppt", "public.data"]
        super.subFolderId = folderInfo.folderId
        super.subFolderType = folderInfo.folderType

        super.docuemntPickerComplete = {(_ success: Bool) -> Void in
            if success {
                self.refreshData(superId: self.folderInfo.folderId)
            }
        }
        presentDocumentPicker(documentTypes: documentTypes)
    }

    // MARK: 
    @objc func importItemClick() {
        CDPrintManager.log("开始进入newtext", type: .InfoLog)
        self.isNeedReloadData = true
        let textVC = CDNewTextViewController()
        textVC.folderId = folderInfo.folderId
        self.navigationController?.pushViewController(textVC, animated: true)

    }

    // MARK: UITableViewDelegate
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 65
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            return 0.01
        } else {
            if textTD.filesArr.count == 0 || textTD.foldersArr.count == 0 {
                return 0.01
            } else {
                return 15
            }
        }
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }

    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.01
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return textTD.foldersArr.count
        } else {
            return textTD.filesArr.count
        }

    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cellId = "textCellId"
        let cell: CDFileTableViewCell! = tableView.dequeueReusableCell(withIdentifier: cellId, for: indexPath) as? CDFileTableViewCell
       
        if batchBtn.isSelected {

            if indexPath.section == 0 {
                let folder: JYFolderInfo = textTD.foldersArr[indexPath.row]
                cell.showSelectIcon = folder.isSelected ? .selected : .show
            } else {
                let fileInfo: JYFileInfo = textTD.filesArr[indexPath.row]
                cell.showSelectIcon = fileInfo.isSelected ? .selected : .show
            }
        } else {
            cell.showSelectIcon = .hide
        }
        if indexPath.section == 0 {
            let folder: JYFolderInfo = textTD.foldersArr[indexPath.row]
            cell.setConfigFolderData(folder: folder)
        } else {
            let fileInfo: JYFileInfo = textTD.filesArr[indexPath.row]
            cell.setConfigFileData(fileInfo: fileInfo)
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if batchBtn.isSelected {
            if indexPath.section == 0 {
                let folder: JYFolderInfo = textTD.foldersArr[indexPath.row]
                if folder.isSelected {
                    selectFolderCount -= 1
                    folder.isSelected = false
                } else {
                    selectFolderCount += 1
                    folder.isSelected = true
                }
            } else {
                let fileInfo: JYFileInfo = textTD.filesArr[indexPath.row]
                if fileInfo.isSelected {
                    selectFileCount -= 1
                    fileInfo.isSelected = false
                } else {
                    selectFileCount += 1
                    fileInfo.isSelected = true
                }
            }

           refreshUI()
        } else {
            if indexPath.section == 0 {
                tableView.transition(subtype: .fromRight, duration: 0.5)

                if CDSignalTon.shared.dirNavArr.count == 0 {
                    CDSignalTon.shared.dirNavArr.add(folderInfo!)
                }
                let folder: JYFolderInfo = textTD.foldersArr[indexPath.row]
                CDSignalTon.shared.dirNavArr.add(folder)
                dirNavBar.reloadBarData()
                showDirNavBar()
                refreshData(superId: folder.folderId)
                currentFolderId = folder.folderId
            } else {
                let fileInfo: JYFileInfo = textTD.filesArr[indexPath.row]
                if fileInfo.fileType == .txt {
                    let messageWindow = CDTextMessageViewController()
                    messageWindow.fileInfo = fileInfo
                    self.navigationController?.pushViewController(messageWindow, animated: true)
                }
//                else{
                    //
                    //                    let quickVC = QLPreviewController()
                    //                    quickVC.delegate = self
                    //                    quickVC.dataSource = self
                    //                    quickVC.currentPreviewItemIndex = indexPath.row
                    //                    quickVC.modalPresentationStyle = .fullScreen
                    //                    present(quickVC, animated: true, completion: nil)
                    //
                    //                    if #available(iOS 11.0, *) {
                    //                        let pdfVC = CDPDFViewController()
                    //                        pdfVC.filePath = fileInfo.path!.absolutePath
                    //                        self.navigationController?.pushViewController(pdfVC, animated: true)
                    //                    } else {
                    //                        // Fallback on earlier versions
                    //                    }
                    //
                    //                }
                else if fileInfo.fileType == .zip {
                    unArchiveZip(fileInfo: fileInfo)
                } else if fileInfo.fileType == .html {
                    let webVC = CDWebViewController1()
                    webVC.url = URL(fileURLWithPath: fileInfo.path!.rootPath)
                    self.navigationController?.pushViewController(webVC, animated: true)
                } else {
                    let filePath = fileInfo.path!.rootPath
                    let url = filePath.pathUrl
                    let documentVC = UIDocumentInteractionController(url: url)
                    documentVC.name = fileInfo.name
                    documentVC.delegate = self
                    documentVC.presentPreview(animated: true)
                }
            }
        }
    }

    func numberOfPreviewItems(in controller: QLPreviewController) -> Int {
        return 1
    }

    func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
        let fileInfo: JYFileInfo = textTD.filesArr[controller.currentPreviewItemIndex]
        let filePath = fileInfo.path!.absolutePath
        let url = filePath.pathUrl
        return url as QLPreviewItem
    }

    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        if batchBtn.isSelected {
            if indexPath.section == 0 {
                let folder: JYFolderInfo = textTD.foldersArr[indexPath.row]
                if folder.isSelected {
                    selectFolderCount -= 1
                    folder.isSelected = false
                } else {
                    selectFolderCount += 1
                    folder.isSelected = true
                }
            } else {
                let fileInfo: JYFileInfo = textTD.filesArr[indexPath.row]
                if fileInfo.isSelected {
                    selectFileCount -= 1
                    fileInfo.isSelected = false
                } else {
                    selectFileCount += 1
                    fileInfo.isSelected = true
                }
            }
            refreshUI()
        }
    }

    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return !batchBtn.isSelected
    }

    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        if indexPath.section == 0 {
            let folder: JYFolderInfo = textTD.foldersArr[indexPath.row]
            let detail = UIContextualAction(style: .normal, title: nil) { (_, _, _) in
                let folderDVC = CDDetailViewController()
                folderDVC.folder = folder
                self.push(to: folderDVC)
            }

            detail.backgroundColor = .baseBgColor
            detail.image = "files_more".image

            let delete = UIContextualAction(style: .normal, title: nil) { (_, _, _) in
                folder.isSelected = true
                self.deleteBarItemClick()
            }
            delete.image = "删除红色".image
            let action = UISwipeActionsConfiguration(actions: [delete, detail])
            return action
        } else {
            let fileInfo: JYFileInfo = textTD.filesArr[indexPath.row]
            let detail = UIContextualAction(style: .normal, title: nil) { (_, _, _) in
                let fileDVC = CDDetailViewController()
                fileDVC.file = fileInfo
                self.push(to: fileDVC)
            }
            detail.backgroundColor = .baseBgColor
            detail.image = "files_more".image
            let delete = UIContextualAction(style: .normal, title: nil) { (_, _, _) in
                fileInfo.isSelected = true
                self.deleteBarItemClick()
            }
            delete.image = "删除红色".image

            let action = UISwipeActionsConfiguration(actions: [delete, detail])
            return action
        }
    }

    func unArchiveZip(fileInfo: JYFileInfo) {
        // 获取解压文件夹中所有子文件，文件夹保存
        func getAllContentsOfDirectory(dirPath: String, superId: Int) {
            // 先保存文件夹，再取子文件保存，子文件夹重复操作
            saveSubFolders(path: dirPath, superId: superId) { (folderId) in
                let T = CDGeneralTool.getAllContentsOfDirectory(dirPath: dirPath)
                for fileName in T.filesArr {
                    self.saveSubFiles(path: fileName, superId: folderId)
                }
                if T.directoiesArr.count > 0 {
                    for dirName in T.directoiesArr {
                        getAllContentsOfDirectory(dirPath: dirName, superId: folderId)
                    }
                } else {
                    CDHUDManager.shared.hideWait()
                    CDHUDManager.shared.showText("解压完成".localize())
                    self.refreshData(superId: self.currentFolderId)
                }
            }
        }

        // 解压
        func unArchiveZipToDirectory(password: String?) {
            CDHUDManager.shared.showWait("解压中...".localize())
            let error = CDGeneralTool.unArchiveZipToDirectory(zip: zipPath, desDirectory: desDirPath, paaword: password)
            if error == nil {
                getAllContentsOfDirectory(dirPath: desDirPath, superId: self.currentFolderId)
            } else {
                CDHUDManager.shared.hideWait()
                CDHUDManager.shared.showText(String(format: "解压失败:%@".localize(), error!.localizedDescription))
            }
        }

        let zipPath = fileInfo.path!.absolutePath
        // 取压缩文件的目录
        var desDirPath = fileInfo.path!.removeSuffix().absolutePath
        var isDir: ObjCBool = true
        if FileManager.default.fileExists(atPath: desDirPath, isDirectory: &isDir) {
            if isDir.boolValue {
                desDirPath = desDirPath + " (\(GetTimeFormat(GetTimestamp())))"
            }
        }

        // 判断压缩包是否加密
        if  CDGeneralTool.checkPasswordIsProtectedZip(zipFile: zipPath) {
            let alert = UIAlertController(title: "加密压缩包".localize(), message: "请输入解压密码".localize(), preferredStyle: .alert)
            var tmpTextFiled: UITextField!
            alert.addTextField { (textFiled) in tmpTextFiled = textFiled }
            alert.addAction(UIAlertAction(title: "确定".localize(), style: .default, handler: { (_) in
                let password = tmpTextFiled.text ?? fileInfo.name
                unArchiveZipToDirectory(password: password)
            }))
            alert.addAction(UIAlertAction(title: "取消".localize(), style: .cancel, handler: { (_) in }))
            present(alert, animated: true, completion: nil)
        } else {
            unArchiveZipToDirectory(password: nil)
        }

    }

    // 保存文件夹,并返回该文件夹的FolderId,作为保存子文件的folderId、文件夹的superId
    func saveSubFolders(path: String, superId: Int, Return:@escaping(_ folderId: Int) -> Void) {
        let nowTime = GetTimestamp()
        let createtime: Int = nowTime
        let folderInfo = JYFolderInfo()
        folderInfo.name = path.lastPathComponent
        folderInfo.folderType = .TextFolder
        folderInfo.isLock = false
        folderInfo.fakeType = .visible
        folderInfo.createTime = createtime
        folderInfo.modifyTime = createtime
//        folderInfo.userId = CDUserId()
        folderInfo.superId = superId
        folderInfo.path = path.relativePath
        let folderId = JYContainer.shared.insertFolder(folder: folderInfo)

        Return(folderId)
    }

    func saveSubFiles(path: String, superId: Int) {
        let fileInfo = JYFileInfo()
        let fileName = path.fileName
        let suffix = path.suffix
        fileInfo.fileType = suffix.fileType
        let fileAttribute = path.fileAttribute
        fileInfo.size = fileAttribute.fileSize
        fileInfo.folderId = superId
        fileInfo.name = fileName
        fileInfo.createTime = fileAttribute.createTime
        fileInfo.path = path.relativePath
        fileInfo.folderType = .TextFolder
        _ = JYContainer.shared.insertFile(file: fileInfo)
    }

    // MARK: UIDocumentInteractionControllerDelegate
    func documentInteractionControllerViewControllerForPreview(_ controller: UIDocumentInteractionController) -> UIViewController {
        return self
    }
    func documentInteractionControllerRectForPreview(_ controller: UIDocumentInteractionController) -> CGRect {
        return self.view.frame
    }
    func documentInteractionControllerViewForPreview(_ controller: UIDocumentInteractionController) -> UIView? {
        return self.view
    }

}
