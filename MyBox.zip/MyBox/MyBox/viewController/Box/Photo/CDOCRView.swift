//
//  CDOCRView.swift
//  PDF
//
//  Created by Kellv on 2024/4/27.
//

import UIKit
import DocX
class CDOCRView: UIView {

    private var alertNib: CDOCRXib!
//    var didSelectHanlder: ((CDTextEditOptions)->Void)?
    var ocrString:String?
    var rootVewController:CDBaseAllViewController?
    var dismissHandler: (()->Void)?
    var goVipHandler: (()->Void)?
    
//    lazy var addFolderAlert: CDNewFolderAlert = {
//        let guaideView = CDNewFolderAlert()
//        guaideView.updateRenameUI(title: "Docx".localize(), placeHolder: "Please enter the docx file name".localize())
//        guaideView.actionHandler = {[weak self] text in
//            guard let self = self else {
//                return true
//            }
//            self.saveDocx(name: text)
//            return true
//        }
//        return guaideView
//    }()
    
    init() {
        super.init(frame: CGRect(x: 0, y: 0, width: CDSCREEN_WIDTH, height: CDSCREEN_HEIGTH))
        
        let backGroundView = UIView(frame: frame)
        backGroundView.alpha = 0.6
        addSubview(backGroundView)
        
        // 毛玻璃效果
        let blurEffect = UIBlurEffect(style: .dark)
        let effectView = UIVisualEffectView(effect: blurEffect)
        effectView.frame = backGroundView.bounds
        backGroundView.addSubview(effectView)
        
//        let optionsview = CDEditBarToolsView(frame: CGRect(x: 0, y: frame.height - 80, width: frame.width, height: 80), types: [.redo,.copy,.doDocx,.export])
//        self.addSubview(optionsview)
//        optionsview.didSelectHanlder = {[weak self]  option in
//            guard let self = self else {
//                return
//            }
//            switch option {
//            case.redo:
//                self.dismiss()
//                guard let dismissHandler = dismissHandler else {return}
//                dismissHandler()
//            case.copy:
//                if CDSignalTon.shared.vipType == falset,
//                   let rootVewController = self.rootVewController {
//                    rootVewController.vipAndRewardUnlock {[weak self] in
//                        guard let self = self else {
//                            return
//                        }
//                        UIPasteboard.general.string = ocrString
//                        CDHUDManager.shared.showText("Copied to the clipboard".localize())
//                    }
//                }else {
//                    UIPasteboard.general.string = ocrString
//                    CDHUDManager.shared.showText("Copied to the clipboard".localize())
//                }
//            case .doDocx:
//                self.addFolderAlert.show()
//                let count = CDConfigFile.getIntValueFromConfigWith(key: .enterVipNoSubscribe)
//
//                if CDSignalTon.shared.vipType == falset && count >= 2,
//                   let rootVewController = self.rootVewController  {
//                    rootVewController.startInterstitialAdsSdk()
//                }
//                
//            case .export:
//                if CDSignalTon.shared.vipType == falset,
//                   let rootVewController = self.rootVewController {
//                    rootVewController.vipAndRewardUnlock {[weak self] in
//                        guard let self = self else {
//                            return
//                        }
//                        self.export()
//                    }
//                }else {
//                    self.export()
//                }
//                
//               
//            default: break
//            }
//        }
//        let nib = UINib(nibName: "CDOCRXib", bundle: nil)
//        let newView = nib.instantiate(withOwner: self, options: nil).first as! CDOCRXib
//
//        newView.frame = CGRect(x: 0, y: 178, width: frame.width, height: optionsview.minY - 178)
//        newView.addRadius(corners: [.topLeft,.topRight], size: CGSize(width: 24, height: 24))
//        self.addSubview(newView)
//        alertNib = newView
//        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillChangeFrame), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)

    }
    
    func export() {
        guard let rootVewController = self.rootVewController,
              let ocrString = self.ocrString else {
            return
        }
        rootVewController.presentShareActivityWith(dataArr: [ocrString as NSObject]) { error in
            if error != nil {
                CDHUDManager.shared.showText("Exported Successed!".localize())
            }
        }
    }
    
    @objc private func keyboardWillChangeFrame(_ notification: Notification) {
        if let endFrame = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as?
                           NSValue)?.cgRectValue {
            if alertNib.textView.isFirstResponder {
                var keyboardHeight = UIScreen.main.bounds.height - endFrame.origin.y
                alertNib.minY = keyboardHeight > 0 ? 0 : 178
            }
        }
    }
    
    
    private func saveDocx(name: String) {
        guard let ocrString = ocrString else {
            return
        }
        
//        let temp = String.RootPath().appendingPathComponent(str: "\(name.removeSpaceAndNewline).docx")
//        do {
//            let atrr = NSAttributedString(string: ocrString)
//            try atrr.writeDocX(to: temp.pathUrl)
//            _ = CDSignalTon.shared.saveFileWithUrl(fileUrl: temp.pathUrl, folderInfo: nil)
//            CDPrintManager.log("文字写入docx成功", type: .InfoLog)
//            CDHUDManager.shared.showText("Saved Successed!".localize())
//        }catch {
//            CDPrintManager.log("文字写入docx失败：\(error.localizedDescription)", type: .ErrorLog)
//        }
    }
    
    func loadNibData(ocrString:String, pageString: String?, languageCode: String?) {
        self.ocrString = ocrString
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineHeightMultiple = 0.98

        alertNib.textView.attributedText = NSAttributedString(string: ocrString, attributes: [NSAttributedString.Key.paragraphStyle: paragraphStyle])
        if let pageString = pageString {
            alertNib.pageIndexLabel.isHidden = false

            alertNib.pageIndexLabel.text = pageString
        }
        if let languageCode = languageCode{
            alertNib.languageBtn.isHidden = false
//            alertNib.languageBtn.setTitle(GetLanguageName(languageCode: languageCode), for: .normal)
        }
       
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func show() {
        DispatchQueue.main.async {
            self.isHidden = false

            UIView.animate(withDuration: 0.25, animations: {
                self.minY = 0
            })
        }
    }
    
    @objc func dismiss() {
        self.isHidden = true
        self.minY = self.height
    }

}

class CDOCRXib: UIView, UITextViewDelegate {
    @IBOutlet weak var languageBtn: UIButton!
    
    @IBOutlet weak var saveBtn: UIButton!
    @IBOutlet weak var pageIndexLabel: UILabel!
    
    @IBOutlet weak var textView: UITextView!

    override func awakeFromNib() {
        super.awakeFromNib()
        textView.textColor = .black
        textView.delegate = self
        pageIndexLabel.isHidden = true
        languageBtn.isHidden = true
        languageBtn.titleLabel?.font = .mid
        languageBtn.layer.cornerRadius = 16
        languageBtn.setTitle("English", for: .normal)
        languageBtn.backgroundColor = UIColor(red: 0.255, green: 0.443, blue: 1, alpha: 0.15)
        
        pageIndexLabel.textColor = UIColor(red: 1, green: 1, blue: 1, alpha: 1)
        pageIndexLabel.font = .mid
        pageIndexLabel.backgroundColor = UIColor(hexStr: "7F89A1")
        pageIndexLabel.textAlignment = .center
        pageIndexLabel.addRadius(corners: .allCorners, size: CGSize(width: 16, height: 16))

        saveBtn.isHidden = true
        saveBtn.titleLabel?.font = .mid
        saveBtn.setTitle("Done".localize(), for: .normal)
        saveBtn.setTitleColor(.white, for: .normal)
        saveBtn.layer.cornerRadius = 16
        saveBtn.backgroundColor = UIColor(red: 0.255, green: 0.443, blue: 1, alpha: 1)

    }
    
    @IBAction func onFinishEdit(_ sender: Any) {
        saveBtn.isHidden = true
        textView.resignFirstResponder()
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        saveBtn.isHidden = false
    }
}
