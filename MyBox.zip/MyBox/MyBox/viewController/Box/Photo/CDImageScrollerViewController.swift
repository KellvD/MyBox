//
//  CDImageScrollerViewController.swift
//  MyRule
//
//  Created by changdong on 2018/12/28.
//  Copyright © 2018 changdong. All rights reserved.
//

import UIKit
import CDMediaEditor

class CDImageScrollerViewController: CDBaseAllViewController {

    public var inputArr: [JYFileInfo] = [] // 所有照片文件
    public var currentIndex: Int!   // 当前索引位置
    public var folderId: Int!

    private var indexLabel: UILabel!
    private var collectionView: UICollectionView!
    private var isHiddenBottom: Bool! = false

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController!.navigationBar.isTranslucent = true

    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController!.navigationBar.isTranslucent = false
    }

    override var prefersStatusBarHidden: Bool {
        return isHiddenBottom
    }
    
    lazy var scanView: UIView = {
        var view = UIView(frame: CGRect(x: 0, y: 0, width: CDSCREEN_HEIGTH, height: 96))
        view.alpha = 0.3
        view.addBackgroundGradient(colors: [ UIColor(red: 0.255, green: 0.443, blue: 1, alpha: 1).cgColor,
                                             UIColor(red: 0.255, green: 0.443, blue: 1, alpha: 0).cgColor], locations: [0, 1], startPoint: CGPoint(x: 0.5, y: 0.25), endPoint: CGPoint(x: 0.5, y: 0.75))
        view.isHidden = true
        self.view.addSubview(view)
        return view
    }()
    
    lazy var ocrView: CDOCRView = {
        let tmpV = CDOCRView()
        tmpV.rootVewController = self
        self.view.addSubview(tmpV)

        return tmpV
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let fileInfo = inputArr[currentIndex]
        self.title = fileInfo.name
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: CDSCREEN_WIDTH, height: CDSCREEN_HEIGTH)
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.scrollDirection = .horizontal

        collectionView = UICollectionView(frame: CGRect(x: 0, y: 0, width: CDSCREEN_WIDTH, height: CDSCREEN_HEIGTH), collectionViewLayout: layout)
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = .black
        collectionView.isPagingEnabled = true
        view.addSubview(collectionView)
        collectionView.register(CDImageCell.self, forCellWithReuseIdentifier: "imageScrollerr")
        collectionView.scrollToItem(at: IndexPath(item: currentIndex, section: 0), at: .centeredHorizontally, animated: false)

        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: LoadImage("fileDetail"), style: .plain, target: self, action: #selector(detailBtnClicked))
        self.navigationItem.rightBarButtonItem?.tintColor = UIColor.white

        self.view.addSubview(self.toolBar)
        self.toolBar.loveItem.setImage(LoadImage(fileInfo.isGrade ? "menu_love_press" : "menu_love_normal"), for: .normal)

        indexLabel = UILabel(frame: CGRect(x: (CDSCREEN_WIDTH - 50)/2, y: self.toolBar.minY - 40, width: 50, height: 30))
        indexLabel.textAlignment = .center
        indexLabel.textColor = UIColor.lightGray
        indexLabel.font = .mid
        indexLabel.text = String(format: "%d/%d", currentIndex+1, inputArr.count)
        indexLabel.backgroundColor = UIColor.clear
        self.view.addSubview(indexLabel)
        let videoTap = UITapGestureRecognizer(target: self, action: #selector(onBarsHiddenOrNot))
        self.view.addGestureRecognizer(videoTap)

        if #available(iOS 11.0, *) {
            self.collectionView.contentInsetAdjustmentBehavior = .scrollableAxes
        } else {
            self.automaticallyAdjustsScrollViewInsets = false
        }

    }

    lazy var toolBar: CDToolBar = {
        let bar = CDToolBar(frame: CGRect(x: 0, y: CDSCREEN_HEIGTH - BottomBarHeight, width: CDSCREEN_WIDTH, height: BottomBarHeight), barType: .ImageScrollerTools, superVC: self)
        return bar
    }()

    func tapQR(message: String) {
        let sheet = UIAlertController(title: "", message: "二维码", preferredStyle: .actionSheet)
        sheet.addAction(UIAlertAction(title: "前往图中所包含的公众号", style: .default, handler: { (_) in
//            let webVC = CDWebViewController()
//            webVC.url = URL(string: message)!
//            self.navigationController?.pushViewController(webVC, animated: true)
        }))
        sheet.addAction(UIAlertAction(title: "取消".localize(), style: .cancel, handler: nil))
        present(sheet, animated: true, completion: nil)

    }

    @objc func detailBtnClicked() {
        let fileInfo = inputArr[currentIndex]
        let fileDetail = CDDetailViewController()
        fileDetail.file = fileInfo
        self.navigationController?.pushViewController(fileDetail, animated: true)
    }
    // MARK: 分享
    @objc func shareBarItemClick() {
        let fileInfo = inputArr[currentIndex]
        let imagePath = fileInfo.path!.absolutePath
        let url = imagePath.pathUrl
        presentShareActivityWith(dataArr: [url as NSObject]) { (_) in}
    }

    // MARK: 收藏
    @objc func loveItemClick() {
        let fileInfo = inputArr[currentIndex]
        if fileInfo.isGrade {
            fileInfo.isGrade = false
            self.toolBar.loveItem.setImage(LoadImage("menu_love_press"), for: .normal)
        } else {
            fileInfo.isGrade = true
            self.toolBar.loveItem.setImage(LoadImage("menu_love_normal"), for: .normal)
        }
        JYContainer.shared.updateFile(isGrade: fileInfo.isGrade,fileId: fileInfo.fileId)

    }

    // MARK: 删除
    @objc func deleteBarItemClick() {
        let fileInfo = inputArr[currentIndex]
        let sheet = UIAlertController(title: nil, message: "删除照片".localize(), preferredStyle: .actionSheet)
        sheet.addAction(UIAlertAction(title: "确定".localize(), style: .destructive, handler: { (_) in
            if let thumbPath = fileInfo.thumbPath?.absolutePath {
                thumbPath.delete()
            }
            if let defaultPath = fileInfo.path?.absolutePath {
                defaultPath.delete()
            }
            JYContainer.shared.deleteFile(fileId: fileInfo.fileId)
            self.inputArr.remove(at: self.currentIndex!)
            DispatchQueue.main.async {
                CDHUDManager.shared.showComplete("删除完成".localize())
                self.collectionView.reloadData()
            }

        }))
        sheet.addAction(UIAlertAction(title: "取消".localize(), style: .cancel, handler: nil))
        self.present(sheet, animated: true, completion: nil)

    }

    @objc func editItemClick() {
        let fileInfo = inputArr[currentIndex]
        let image = UIImage(contentsOfFile: fileInfo.path!.absolutePath)
        let photoConfig = PhotoEditorConfiguration()
        let vc = EditorController.init(image: image!, config: photoConfig)
        vc.photoEditorDelegate = self
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true, completion: nil)
    }
    
    @objc func ocrItemClick() {
        let fileInfo = inputArr[currentIndex]
        let image = UIImage(contentsOfFile: fileInfo.path!.absolutePath)

        let vc = CDLanguagePickerViewController()
        vc.selecthandler = {[weak self] lanCode in
            guard let self = self else {
                return
            }
            
            self.toggleAnimation()
            CDOCRTools.ocrText(in: image!, recognitionLanguages: [lanCode]) { ocrStrs,error in
                self.toggleAnimation()
                if error != nil {
                    return
                }
                if ocrStrs.isEmpty {
                    CDHUDManager.shared.showText("No text recognize".localize())
                    return
                }
//                self.ocrView.loadNibData(ocrString: ocrStrs.joined(separator: "\n"), pageString: "\(self.currentIndex + 1)/\(self.previewImages.count)", languageCode: lanCode)
                self.ocrView.show()
            }
        }
        self.present(vc, animated: true)
        
    }
    
    // MARK: NotificationCenter
    @objc func onBarsHiddenOrNot() {
        self.isHiddenBottom = !self.isHiddenBottom
        var rect = self.toolBar.frame
        UIView.animate(withDuration: 0.25) {
            rect.origin.y = self.isHiddenBottom ? CDSCREEN_HEIGTH : (CDSCREEN_HEIGTH - BottomBarHeight)
            self.toolBar.frame = rect
        }

        self.navigationController?.setNavigationBarHidden(self.isHiddenBottom, animated: true)

    }
    
    func toggleAnimation() {
        DispatchQueue.main.async {
            self.isAnimating.toggle()
            self.startAnimatingView()
        }
    }
    var isAnimating = false

    func startAnimatingView() {
        self.scanView.isHidden = !isAnimating
        self.scanView.frame.origin.y = 0
        guard isAnimating else { return }

        
        
        UIView.animate(withDuration: 3.0) {
            if self.isAnimating {
//                self.scanView.minY = self.height - self.scanView.height
            }
        } completion: { _ in
            self.startAnimatingView()
        }

        UIView.animate(withDuration: 3.0, delay: 0, options: [.curveEaseInOut, .repeat], animations: {
            // 移动视图到最底部
        }, completion: nil)
    }
}

extension CDImageScrollerViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return inputArr.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "imageScrollerr", for: indexPath) as! CDImageCell
        let tmpFile: JYFileInfo = inputArr[indexPath.item]
        cell.setScrollerImageData(fileInfo: tmpFile)
        cell.longTapHandle = {(massage) -> Void in
            self.tapQR(message: massage)
        }
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didEndDisplaying cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        let firstIndexPath = collectionView.indexPathsForVisibleItems.first

        let page = firstIndexPath!.item
        let fileinfo = inputArr[page]
        DispatchQueue.main.async {
            self.toolBar.loveItem.setImage(LoadImage(fileinfo.isGrade ? "menu_love_press" : "menu_love_normal"), for: .normal)
            self.toolBar.editItem.isEnabled = !(fileinfo.fileType == .gif)
        }

        self.title = fileinfo.name
        currentIndex = page
        indexLabel.text = String(format: "%d/%d", currentIndex+1, inputArr.count)
    }

}

extension CDImageScrollerViewController: PhotoEditorViewControllerDelegate {
    func photoEditorViewController(_ photoEditorViewController: PhotoEditorViewController, didFinish result: PhotoEditResult) {

        CDSignalTon.shared.saveFileWithUrl(fileUrl: result.editedImageURL, folderId: self.folderId, subFolderType: .ImageFolder, isFromDocment: false)
    }

    func photoEditorViewController(_ photoEditorViewController: PhotoEditorViewController, loadTitleChartlet response: @escaping EditorTitleChartletResponse) {
        let chartLet = EditorChartlet(image: "weixiao".image)
        response([chartLet])
    }
    func photoEditorViewController(_ photoEditorViewController: PhotoEditorViewController, titleChartlet: EditorChartlet, titleIndex: Int, loadChartletList response: @escaping EditorChartletListResponse) {
        let emojiPath = Bundle.main.path(forResource: "ClassicExpressionPNGList", ofType: "plist")
        let arr = NSArray(contentsOfFile: emojiPath!) as! [NSDictionary]
        var charts: [EditorChartlet] = []
        arr.forEach { item in
            let name = item.object(forKey: "png") as! String
//            let title = item["zh-Hant"] as! String

            let chartLet = EditorChartlet(image: name.image)
            charts.append(chartLet)
        }
        response(titleIndex, charts)
    }

}
