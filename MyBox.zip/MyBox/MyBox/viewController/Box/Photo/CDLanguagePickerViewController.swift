//
//  CDLanguagePickerViewController.swift
//  PDF
//
//  Created by Kellv on 2024/5/9.
//

import UIKit

class CDLanguagePickerViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    
    var collectionView: UICollectionView!
    var selectIndex = 0
    var dataArr: [String] = Locale.preferredLanguages
    var selecthandler: ((String) -> Void)?
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        let titleLabel = UILabel(frame: CGRect(x: 16, y: 24, width: CDSCREEN_WIDTH - 32, height: 24))
        titleLabel.textColor = .black
//        titleLabel.font = .helvBold(24)
        titleLabel.textAlignment = .center
        titleLabel.text = "Choose language".localize()
        view.addSubview(titleLabel)
        
        let cancelBtn = UIButton(type: .custom)
        cancelBtn.frame = CGRect(x: 16, y: CDViewHeight - 24 - 56, width: (CDSCREEN_WIDTH - 16 * 2 - 10)/2, height: 56)
        cancelBtn.setTitle("Cancel".localize(), for: .normal)
        cancelBtn.setTitleColor(UIColor(red: 0.498, green: 0.537, blue: 0.631, alpha: 1), for: .normal)
//        cancelBtn.titleLabel?.font = .helvBold(16)
        cancelBtn.layer.cornerRadius = 28
        cancelBtn.addTarget(self, action: #selector(onCancelAction), for: .touchUpInside)
        cancelBtn.backgroundColor =  UIColor(red: 0.918, green: 0.918, blue: 0.945, alpha: 1)
        view.addSubview(cancelBtn)

        let confimBtn = UIButton(type: .custom)
        confimBtn.setTitle("Confirm".localize(), for: .normal)
        confimBtn.frame = CGRect(x: cancelBtn.maxX + 10, y: cancelBtn.minY, width: (CDSCREEN_WIDTH - 16 * 2 - 10)/2, height: 56)
        confimBtn.setTitleColor(.white, for: .normal)
//        confimBtn.titleLabel?.font = .helvBold(16)
        confimBtn.layer.cornerRadius = 28
        confimBtn.addTarget(self, action: #selector(onConfirmAction), for: .touchUpInside)
        confimBtn.backgroundColor =  UIColor(red: 0.255, green: 0.443, blue: 1, alpha: 1)
        view.addSubview(confimBtn)

        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = 8
        layout.itemSize = CGSize(width: CDSCREEN_WIDTH - 32, height: 56)
        
        collectionView = UICollectionView(frame: CGRect(x: 0, y: titleLabel.maxY + 24, width: CDSCREEN_WIDTH, height: cancelBtn.minY - 48 - titleLabel.maxY), collectionViewLayout: layout)
        collectionView.register(CDlanguageCell.self, forCellWithReuseIdentifier: "CDlanguageCell")

        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = .white
        view.addSubview(collectionView)

    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CDlanguageCell", for: indexPath) as! CDlanguageCell
        
        cell.titleLabel.text = GetLanguageName(languageCode: dataArr[indexPath.item])
        cell.titleLabel.backgroundColor = indexPath.item == selectIndex ? UIColor(red: 0.255, green: 0.443, blue: 1, alpha: 1) : UIColor(red: 0.918, green: 0.918, blue: 0.945, alpha: 1)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectIndex = indexPath.item
        collectionView.reloadData()
    }
    
    @objc func onConfirmAction(_ sender: Any) {
        self.dismiss(animated: true) {[weak self] in
            guard let self = self,
                  let selecthandler = self.selecthandler else { return }
            let ref = self.dataArr[selectIndex]
            selecthandler(ref)
        }
        
    }
    
    @objc func onCancelAction(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
   
}


class CDlanguageCell: UICollectionViewCell {
    var titleLabel: UILabel!
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        titleLabel = UILabel(frame: self.bounds)
        titleLabel.layer.cornerRadius = self.height/2.0
        titleLabel.clipsToBounds = true
        titleLabel.textColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
//        titleLabel.font = .regular(16)
        titleLabel.textAlignment = .center
        self.addSubview(titleLabel)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
