//
//  CDSafeViewController.swift
//  MyRule
//
//  Created by changdong on 2018/12/5.
//  Copyright © 2018 changdong. All rights reserved.
//

import UIKit

class CDSafeViewController: CDBaseAllViewController, UITableViewDelegate, UITableViewDataSource, CDPopMenuViewDelegate {

    var tableView: UITableView!
    var folderArr: [[JYFolderInfo]] = []

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        initData()
    }

    lazy var addAlert: CDNewFolderAlert = {
        let alert = CDNewFolderAlert()
        alert.actionBlock = {[weak self] flag in
            guard let self = self else {
                return
            }
            if flag {
                self.initData()
            }
        }
        return alert
    }()
    override func viewDidLoad() {
        super.viewDidLoad()

        hiddBackbutton()
        self.tableView = UITableView(frame: CGRect(x: 0, y: 0, width: CDSCREEN_WIDTH, height: CDViewHeight), style: .grouped)
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.separatorStyle = .none
        self.view.addSubview(self.tableView)
        tableView.register(CDFolderTableViewCell.self, forCellReuseIdentifier: "safeCellIdentifier")

        let rightItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addfFolderClick))
        rightItem.tintColor = .white
        self.navigationItem.rightBarButtonItem = rightItem
    }

    func initData() {
        folderArr = JYContainer.shared.queryAllFolder(userId: CDSignalTon.shared.userInfo.userId)
        tableView.reloadData()
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return folderArr.count
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 65
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return SECTION_SPACE
    }

    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.1
    }

    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return folderArr[section].count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "safeCellIdentifier") as! CDFolderTableViewCell

        let folder: JYFolderInfo = folderArr[indexPath.section][indexPath.row]
        cell.configDataWith(folderInfo: folder)

        cell.separatorLineIsHidden = indexPath.row == folderArr[indexPath.section].count - 1
        return cell

    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let folderInfo: JYFolderInfo = self.folderArr[indexPath.section][indexPath.row]
        if folderInfo.folderType == .ImageFolder {
            let imageVC = CDImageViewController()
            imageVC.folderInfo = folderInfo
            imageVC.title = "图片文件".localize()
            imageVC.hidesBottomBarWhenPushed = true
            self.push(to: imageVC)

        } else if folderInfo.folderType == .AudioFolder {
            let audioVC = CDAudioViewController()
            audioVC.title = "音频文件".localize()
            audioVC.folderInfo = folderInfo
            audioVC.hidesBottomBarWhenPushed = true
            self.push(to: audioVC)
        } else if folderInfo.folderType == .VideoFolder {
            let videoVC = CDVideoViewController()
            videoVC.folderInfo = folderInfo
            videoVC.title = "视频文件".localize()
            videoVC.hidesBottomBarWhenPushed = true
            self.push(to: videoVC)
        } else if folderInfo.folderType == .TextFolder {
            let textVC = CDTextViewController()
            textVC.folderInfo = folderInfo
            textVC.title = "文本文件".localize()
            textVC.hidesBottomBarWhenPushed = true
            self.push(to: textVC)
        }

    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let folderInfo: JYFolderInfo = self.folderArr[indexPath.section][indexPath.row]
        let detail = UIContextualAction(style: .normal, title: nil) { (_, _, _) in
            let folderDVC = CDDetailViewController()
            folderDVC.folder = folderInfo
            folderDVC.hidesBottomBarWhenPushed = true
            self.push(to: folderDVC)
        }
        detail.backgroundColor = .baseBgColor
        detail.image = "files_more".image
        if !folderInfo.isLock {
            let delete = UIContextualAction(style: .normal, title: nil) { (_, _, _) in
                JYContainer.shared.deleteFolder(folderId: folderInfo.folderId)
                self.initData()
                tableView.reloadData()
            }
            delete.image = "删除红色".image

            let action = UISwipeActionsConfiguration(actions: [delete, detail])
            return action
        } else {
            let action = UISwipeActionsConfiguration(actions: [detail])
            return action
        }
    }
    
    @objc func addfFolderClick() {
        self.addAlert.show()
    }

    // MARK: 
    func onSelectedPopMenu(title: String) {
        if title == "新建文件夹" {
            let newVC = CDNewFolderViewController()
            newVC.hidesBottomBarWhenPushed  = true
            self.navigationController?.pushViewController(newVC, animated: true)
        } else if title == "扫一扫" {
            let camera = CDCameraViewController()
            camera.isVideo = false
            camera.modalPresentationStyle = .fullScreen
            CDSignalTon.shared.customPickerView = camera
            self.present(camera, animated: true, completion: nil)
        } else if title == "电子书" {
           let setVC = CDMineViewController()
            setVC.hidesBottomBarWhenPushed  = true
           self.navigationController?.pushViewController(setVC, animated: true)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
