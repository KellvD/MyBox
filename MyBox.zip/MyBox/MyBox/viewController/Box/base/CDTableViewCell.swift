//
//  CDAudioCell.swift
//  MyRule
//
//  Created by changdong on 2018/12/23.
//  Copyright © 2018 changdong. All rights reserved.
//

import UIKit
import SnapKit
enum CDSelectIconState: Int {
    case hide = 1 // 隐藏
    case show = 2 // 显示
    case selected = 3 // 选中
}
class CDFileTableViewCell: UITableViewCell {

    var fileNameL: UILabel!
    var fileCreateTimeL: UILabel!
    var audioLengthL: UILabel!
    var headImage: UIImageView!
    var selectImage: UIImageView!
    var isSelect: Bool = false
    var showSelectIcon: CDSelectIconState!{
        didSet {
            
        }
    }

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {

        super.init(style: style, reuseIdentifier: reuseIdentifier)

        let view = UIView()
        self.selectedBackgroundView = view
        self.selectedBackgroundView?.backgroundColor = .cellSelectColor

        headImage = UIImageView(frame: .zero)
        self.contentView.addSubview(headImage)
        headImage.snp.makeConstraints { make in
            make.left.equalTo(16)
            make.centerY.equalToSuperview()
            make.width.height.equalTo(45)
        }

        selectImage = UIImageView(frame: .zero)
        selectImage.image = LoadImage("no_selected")
        self.contentView.addSubview(selectImage)
        selectImage.snp.makeConstraints { make in
            make.right.equalToSuperview().offset(-15)
            make.centerY.equalToSuperview()
            make.width.height.equalTo(30)
        }
        selectImage.isHidden = true
        
        fileNameL = UILabel(frame: .zero)
        fileNameL.textColor = .textBlack
        fileNameL.font = .mid
        fileNameL.lineBreakMode = .byTruncatingMiddle
        fileNameL.textAlignment = .left
        self.contentView.addSubview(fileNameL)
        fileNameL.snp.makeConstraints { make in
            make.left.equalTo(headImage.snp.right).offset(10)
            make.right.equalTo(selectImage.snp.left).offset(-10)
            make.top.equalTo(headImage)
            make.height.equalTo(22)
        }
        
        
        fileCreateTimeL = UILabel(frame: .zero)
        fileCreateTimeL.textColor = .textGray
        fileCreateTimeL.textAlignment = .left
        fileCreateTimeL.font = .small
        self.contentView.addSubview(fileCreateTimeL)
        fileCreateTimeL.snp.makeConstraints { make in
            make.left.right.equalTo(fileNameL)
            make.top.equalTo(fileNameL.snp.bottom)
        }
        
        audioLengthL = UILabel(frame: CGRect(x: CDSCREEN_WIDTH-95, y: fileNameL.frame.maxY, width: 80, height: 30))
        audioLengthL.textAlignment = .center
        audioLengthL.textColor = .textGray
        audioLengthL.font = .small
        audioLengthL.textAlignment = .right
        self.contentView.addSubview(audioLengthL)
        audioLengthL.isHidden = true
        audioLengthL.snp.makeConstraints { make in
            make.right.equalToSuperview().offset(-10)
            make.top.equalTo(fileNameL.snp.bottom)
        }

        let line = UIView(frame: CGRect(x: 5, y: 64, width: CDSCREEN_WIDTH-10, height: 1))
        line.backgroundColor = .separatorColor
        self.contentView.addSubview(line)
        line.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(5)
            make.right.equalToSuperview().offset(-5)
            make.height.equalTo(1)
            make.bottom.equalToSuperview()
        }
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func setConfigFileData(fileInfo: JYFileInfo) {
        fileNameL.text = fileInfo.name
        fileCreateTimeL.text = GetTimeFormat(fileInfo.createTime)

        let imageName = GetFileHeadImage(type: fileInfo.fileType)
        headImage.image = UIImage(named: imageName!)
        selectImage.isHidden = showSelectIcon == .hide
        if showSelectIcon == .show {
            selectImage.image = LoadImage("no_selected")
        } else if showSelectIcon == .selected {
            selectImage.image = LoadImage("selected")
        }

        if fileInfo.fileType == .audio {
            audioLengthL.isHidden = false
            audioLengthL.text = GetMMSSFromSS(timeLength: fileInfo.timeLength)
        }
    }

    func setConfigFolderData(folder: JYFolderInfo) {
        fileNameL.text = folder.name
        fileCreateTimeL.text = GetTimeFormat(folder.createTime)
        headImage.image = UIImage(named: "file_dir_big")

        selectImage.isHidden = showSelectIcon == .hide
        if showSelectIcon == .show {
            selectImage.image = LoadImage("no_selected")
        } else if showSelectIcon == .selected {
            selectImage.image = LoadImage("selected")
        }
    }

}

class CDFolderTableViewCell: UITableViewCell {

    private var headImageView: UIImageView!
    private var titleLabel: UILabel!
    private var separatorLine: UIView!
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)

        let view = UIView()
        self.selectedBackgroundView = view
        self.selectedBackgroundView?.backgroundColor = .cellSelectColor

        headImageView = UIImageView()
        headImageView.backgroundColor = UIColor.clear
        contentView.addSubview(headImageView)
        headImageView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(10.0)
            make.centerY.equalToSuperview()
            make.width.height.equalTo(45.0)
        }

        titleLabel = UILabel()
        titleLabel.textColor = .textBlack
        contentView.addSubview(titleLabel)
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(headImageView.snp.right).offset(15.0)
            make.centerY.equalToSuperview()
            make.height.equalTo(25.0)
        }

        separatorLine = UIView()
        separatorLine.backgroundColor = .separatorColor
        self.contentView.addSubview(separatorLine)
        separatorLine.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview()
            make.height.equalTo(1)
            make.left.equalToSuperview().offset(15.0)
            make.right.equalToSuperview().offset(-15.0)
        }

    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func configDataWith(folderInfo: JYFolderInfo) {
        switch folderInfo.folderType {
        case .ImageFolder:
            self.headImageView.image = UIImage(named: "icon_image")
        case .AudioFolder:
            self.headImageView.image = UIImage(named: "icon_audio")
        case .VideoFolder:
            self.headImageView.image = UIImage(named: "icon_media")
        case .TextFolder:
            self.headImageView.image = UIImage(named: "icon_txt")
        case .none:
            break
        }

        self.titleLabel.text = folderInfo.name
    }

    var separatorLineIsHidden: Bool {
        set {
            separatorLine.isHidden = newValue
        }
        get {
            return false
        }
    }

}
