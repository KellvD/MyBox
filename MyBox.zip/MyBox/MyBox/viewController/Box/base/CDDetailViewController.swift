//
//  CDDetailViewController.swift
//  MyRule
//
//  Created by changdong on 2018/12/11.
//  Copyright © 2018 changdong. All rights reserved.
//

import UIKit

class CDDetailViewController: CDBaseAllViewController {
    var folder: JYFolderInfo?
    var file: JYFileInfo?
    private var models: [[CDSwitchMode]] = []
    private var tableView: CDSwitchTableView!
    
    lazy var renameAlert: CDInputAlert = {
        let alert = CDInputAlert()
        alert.actionHandler = {[weak self] content in
            guard let self = self else {
                return
            }
            if let folder = self.folder {
                CDPrintManager.log("文件夹重命名-原名:\(folder.name ?? ""),新名:\(content)", type: .InfoLog)
                JYContainer.shared.updateFolder(name: content,folderId: folder.folderId)
            }
            
            if let file = file {
                CDPrintManager.log("文件重命名-原名:\(file.name ?? ""),新名:\(content)", type: .InfoLog)
                JYContainer.shared.updateFile(name: content, fileId: file.fileId)
            }
            
            CDHUDManager.shared.showComplete("重命名成功！".localize())
            self.tableView.reloadData()
        }
        return alert
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initFolderDetailData()
        self.title = file?.name ?? folder?.name
    
        tableView = CDSwitchTableView(frame: CGRect(x: 0, y: 0, width: CDSCREEN_WIDTH, height: CDViewHeight), modes: models, didSelectHandler: {[weak self] mode, swi in
            guard let self = self else {
                return
            }
            didSelectMode(with: mode, swi: swi)
        })
        view.addSubview(tableView)

        if let folder = folder,
           !folder.isLock {
            let button = UIButton(frame: CGRect(x: 30, y: CDViewHeight - 48 - 20, width: CDSCREEN_WIDTH - 60, height: 48), text: "删除", textColor: .white, imageNormal: nil, target: self, function: #selector(delectFolderClick), supView: view)
            button.backgroundColor = .red
            button.layer.cornerRadius = 4.0
            view.bringSubviewToFront(button)
        }
        
    }

    func initFolderDetailData() {
        if let folder = folder {
            models = [
                [
                    CDSwitchMode(type: .name,value: folder.name,isCanEdit: true)
                ],
                [
                    CDSwitchMode(type: .createTime,value: GetTimeFormat(folder.createTime)),
                    CDSwitchMode(type: .modifyTime,value: GetTimeFormat(folder.modifyTime))
                ],
                [
                    CDSwitchMode(type: .fileCount,value: ""),
                    CDSwitchMode(type: .size,value: "")
                ],
                [
                    CDSwitchMode(type: .mark,value: folder.markInfo)
                ]
            ]
        }else if let file = file {
            self.title = file.name
            var option:[CDSwitchMode] = []
            if file.fileType == .image || file.fileType == .gif {
                option = [
                    CDSwitchMode(type: .size,value: "\(file.width) x \(file.height)"),
                    CDSwitchMode(type: .length,value: GetSizeFormat(fileSize: file.size)),
                ]
            } else if  file.fileType == .audio || file.fileType == .video {
                option = [
                    CDSwitchMode(type: .length,value: GetSizeFormat(fileSize: file.size)),
                    CDSwitchMode(type: .during,value: GetMMSSFromSS(timeLength: file.timeLength))
                ]
            } else {
                option = [
                    CDSwitchMode(type: .size,value: GetSizeFormat(fileSize: file.size))
                ]
                
            }
            
            models = [
                [
                    CDSwitchMode(type: .name,value: file.name,isCanEdit: true),
                    CDSwitchMode(type: .name,value: file.path!.suffix)
                ],
                [
                    CDSwitchMode(type: .createTime,value: GetTimeFormat(file.createTime)),
                    CDSwitchMode(type: .modifyTime,value: GetTimeFormat(file.importTime))
                ],
                option,
                [
                    CDSwitchMode(type: .mark ,value: file.markInfo,isCanEdit: true)
                ]
            ]
        }
    }
    
    func didSelectMode(with mode: CDSwitchMode, swi: UISwitch?) {
        switch mode.type {
        case .name:
            self.renameAlert.isMultipleLines = false
            self.renameAlert.show()
        case .fake:
//            changeFakeModel(swi: swi!)
            break
        case .mark:
            self.renameAlert.isMultipleLines = true
            self.renameAlert.show()
        default : break
        }
    }

    @objc func delectFolderClick() {
        guard let folder = self.folder else {
            return
        }
        JYContainer.shared.deleteFolder(folderId: folder.folderId)
        let allFileArr = JYContainer.shared.queryAllFile(folderId: folder.folderId)
        for file in allFileArr {
            if file.folderType == .ImageFolder || file.folderType == .VideoFolder {
                if let thumpPath = file.thumbPath?.absolutePath {
                    thumpPath.delete()
                }
            }
            if let defaultPath = file.path?.absolutePath {
                defaultPath.delete()
            }
            JYContainer.shared.deleteFile(fileId: file.fileId)
        }

        self.navigationController?.popViewController(animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
