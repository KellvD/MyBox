//
//  CDToolsBar.swift
//  MyBox
//
//  Created by Kellv on 2024/7/8.
//  Copyright © 2024 Kellv. 2012-2019. All rights reserved.
//

import UIKit

class CDToolsBar: UIView {
 
    enum CDBarType: Int {
        case file
        case camera
        case library
        case addText
        case record
        case input
        case forward
        case output
        case move
        case delete
        case append
        case love
        case edit
        case ocr
    }
    let textarr = ["Add","Rotate","Share","Delete","More",
    "Mark Up","New Page","Signature","Camera_Add","back_Imag"]
    var barTypes:[CDBarType] = []
    var didSelectToolHandler: ((CDBarType) ->Void)?
    var btnWidth: CGFloat = 0
    var screenHeight = CDSCREEN_HEIGTH

    init(frame: CGRect = CGRect(x: 0, y: CDSCREEN_HEIGTH - BottomBarHeight, width: CDSCREEN_WIDTH, height: BottomBarHeight),
         barTypes: [CDBarType],
         handler: @escaping (CDBarType) ->Void) {
        super.init(frame: frame)

        let line = UIView(frame: CGRect(x: 0, y: 0, width: self.width, height: 1))
        line.backgroundColor = UIColor(red: 0.965, green: 0.965, blue: 0.965, alpha: 1)
        addSubview(line)
        backgroundColor = .white
        self.didSelectToolHandler = handler

        btnWidth = CDSCREEN_WIDTH / CGFloat(barTypes.count)
        for i in 0..<barTypes.count {
            let type = barTypes[i]
            let text = textarr[type.rawValue-100]
            let item = createButton(x:btnWidth * CGFloat(i), title:text, imageName: "\(text)_tool")
            item.tag = type.rawValue
        }
    }
    
    func createButton(x:CGFloat, title:String?, imageName: String?) -> UIButton {
   
        if let title = title,
           let imagesString = imageName {
            let button = CDButton(frame: CGRect(x: x, y: 0, width: btnWidth, height: self.height))
            button.load(title: title, imageString: imagesString)
            button.addTarget(self, action: #selector(buttonAction(_:)), for: .touchUpInside)
            addSubview(button)
            return button
        }else {
            let button = UIButton(frame: CGRect(x: x, y: 0, width: btnWidth, height: self.height),text: title, textColor: nil, imageNormal: imageName, target: self, function: #selector(buttonAction(_:)), supView: self)
            return button
        }
    }
    
    @objc func buttonAction(_ sender: UIButton) {
        guard let didSelectToolHandler = didSelectToolHandler else {
            assertionFailure("actionHandler is nil")
            return
        }
        
        didSelectToolHandler(CDBarType(rawValue: sender.tag)!)
    }

    
    
    func pop() {
        self.isHidden = false
        UIView.animate(withDuration: 0.25) { [weak self] in
            guard let self = self else {
                return
            }
            var rect = self.frame
            rect.origin.y = self.screenHeight - self.height
            self.frame = rect
        }
    }
    
    @objc func dismiss() {
        UIView.animate(withDuration: 0.25) { [weak self] in
            guard let self = self else {
                return
            }
            var rect = self.frame
            rect.origin.y = self.screenHeight
            self.frame = rect
        }

    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }


}
