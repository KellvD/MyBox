//
//  CDNewFolderAlert.swift
//  MyBox
//
//  Created by Kellv on 2024/11/24.
//  Copyright © 2024 Kellv. 2012-2019. All rights reserved.
//

import UIKit

class CDNewFolderAlert: UIView {
    var actionBlock:((Bool) -> Void)?

    override init(frame: CGRect = CGRect(x: 0, y: CDSCREEN_HEIGTH, width: CDSCREEN_WIDTH, height: CDSCREEN_HEIGTH)) {
        super.init(frame: CGRect(x: 0, y: CDSCREEN_HEIGTH, width: CDSCREEN_WIDTH, height: CDSCREEN_HEIGTH))
        addBlurView()
        
        let xib = UINib(nibName: "CDNewFolderAlert", bundle: nil)
        let popView = xib.instantiate(withOwner: self, options: nil).first as! CDNewFolderXib
        popView.frame = CGRect(x: 16, y: self.height/2.0 - 140, width: self.width - 32, height: 280)
        popView.layer.cornerRadius = 8
        popView.actionBlock = {[weak self] flag in
            guard let self = self else{
                return
            }
            
            dismiss()
            guard let actionBlock = actionBlock else {
                return
            }
            actionBlock(flag)
            
        }
        self.addSubview(popView)
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func show() {
        UIView.animate(withDuration: 0.25) {
            self.minY = 0
        }
    }
    
    @objc func dismiss() {
        UIView.animate(withDuration: 0.25) {
            self.minY = CDSCREEN_HEIGTH
        }
    }
}


class CDNewFolderXib: UIView {
    
    @IBOutlet weak var titlelabel: UILabel!
    @IBOutlet weak var subTileLabe: UILabel!
    @IBOutlet weak var segmentView: UISegmentedControl!
    @IBOutlet weak var inputFiled: UITextField!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var createBtn: UIButton!
    
    var actionBlock:((Bool) -> Void)?
    
    private var folderType: NSFolderType = .ImageFolder
    override func awakeFromNib() {
        super.awakeFromNib()
        titlelabel.set(titleColor: .titleColor, font: .titleFont)
        titlelabel.text = "New Folder"
        
        subTileLabe.set(titleColor: .subTitleColor, font: .subTitleFont)
        subTileLabe.text = ""
        
        segmentView.selectedSegmentTintColor = .customBlue
        
        let leftBgView = UIView(frame: CGRect(x: 8, y: 10, width: 15, height: 15))
        inputFiled.leftView = leftBgView
        inputFiled.leftViewMode = .always
        inputFiled.layer.backgroundColor = UIColor(red: 0.864, green: 0.874, blue: 0.912, alpha: 1).cgColor
        inputFiled.layer.cornerRadius = 8
        inputFiled.layer.borderWidth = 1
        inputFiled.clearButtonMode = .whileEditing
        inputFiled.layer.borderColor = UIColor(red: 0.818, green: 0.828, blue: 0.862, alpha: 1).cgColor
        inputFiled.returnKeyType = .done
        inputFiled.placeholder = "Enter a folder name".localize()
        cancelBtn.setUI(title: "Cancel".localize(), type: .cancel)
        createBtn.setUI(title: "Create".localize(), type: .normal)
    }
    
    @IBAction func onButtonTouchAction(_ sender: UIButton) {
        guard let actionBlock = actionBlock else {
            return
        }
        
        if sender.tag == 0 {
            actionBlock(false)
        }else {
            let folderName = inputFiled.text ?? "Unkown".localize()
            let folderInfo = JYFolderInfo()
            folderInfo.name = folderName
            folderInfo.folderType = folderType
            folderInfo.isLock = false
            folderInfo.fakeType = .visible
            folderInfo.userIds = [JYCurrentUser().userId]
     
            folderInfo.superId = ROOTSUPERID
            _ = JYContainer.shared.insertFolder(folder: folderInfo)
            CDPrintManager.log("创建新文件夹:\(folderName)", type: .InfoLog)
            actionBlock(true)
        }
    }
    
    @IBAction func onSelectSgementView(_ sender: UISegmentedControl) {
        folderType = NSFolderType(rawValue: segmentView.selectedSegmentIndex)!
    }
}
