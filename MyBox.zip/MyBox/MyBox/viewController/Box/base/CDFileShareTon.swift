//
//  CDFileSignalTon.swift
//  MyBox
//
//  Created by Kellv on 2024/11/24.
//  Copyright © 2024 Kellv. 2012-2019. All rights reserved.
//

import Foundation

class CDFileSignalTon: NSObject {
    static let shared = CDFileSignalTon()
    private override init() {
        super.init()
    }
    
    func addFolder(name:String, folderType: NSFolderType, isLock: Bool = true) {
//        let time = GetTimestamp()
//        let folderInfo = JYFolderInfo()
//        folderInfo.name = name
//        folderInfo.folderType = folderType
//        folderInfo.isLock = isLock
//        folderInfo.fakeType = .visible
//        folderInfo.userId = CDUserId()
//        folderInfo.createTime = Int(time)
//        folderInfo.modifyTime = Int(time)
//        folderInfo.superId = ROOTSUPERID
//        _ = JYContainer.shared.insertFolder(folder: folderInfo)
//        CDPrintManager.log("创建新文件夹:\(name)", type: .InfoLog)
    }
}

