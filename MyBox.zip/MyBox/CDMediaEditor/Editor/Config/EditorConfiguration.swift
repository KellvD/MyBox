//
//  EditorConfiguration.swift
//  HXPHPicker
//
//  Created by Slience on 2021/1/9.
//

import Foundation

open class EditorConfiguration: BaseConfiguration {
    
    public override init() {
        super.init()
        prefersStatusBarHidden = true
    }
}
